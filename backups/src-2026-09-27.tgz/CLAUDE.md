@AGENTS.md

# my_pm

Personal PM app: markdown store (Project → Feature → Task) + deterministic scheduler + MCP server (`/api/mcp`) for AI agents. See README.md.

- Tasks reach their project only through `feature`; inheritance (priority, deadline, on-hold) lives in `src/lib/hierarchy.ts` — use it rather than re-deriving.
- Keep `src/lib/scheduler.ts` pure and covered by `src/lib/scheduler.test.ts`; run `npm test` after touching scheduling or estimation.
- All persistence goes through `src/lib/repo.ts` → `Repository` (`src/lib/repository/`: Postgres via `DATABASE_URL`, or markdown files on the local fs). Never write files or SQL outside a repository.
- Schema changes: add a new `migrations/NNN_*.sql` (never edit an applied one), run `npm run db:migrate` on your dev branch; `npm test` covers both backends.
- New task/feature fields: add to the zod schema in `src/lib/types.ts` (key order there is the frontmatter order; Postgres column names are the same keys, so add a migration too), then expose via `TaskPatch`/`NewTask` in `repo.ts` and the MCP tools.
- Checks: `npm run typecheck && npm run lint && npm test && npm run build`.
