import Link from "next/link";
import { Outlook } from "@/components/outlook";
import { TaskTable } from "@/components/task-table";
import { Badge, Card, Empty, PriorityBadge } from "@/components/ui";
import { lookup, type Lookup } from "@/lib/hierarchy";
import { featureSummary, projectSummary, scheduleFor } from "@/lib/planning";
import { loadWorkspace, type Workspace } from "@/lib/repo";
import type { ScheduleResult } from "@/lib/scheduler";
import { PRIORITIES, type Feature, type Task } from "@/lib/types";

export const dynamic = "force-dynamic";

const isOpen = (status: string) => status !== "done" && status !== "cancelled";

function FeatureCard(props: { feature: Feature; tasks: Task[]; ws: Workspace; plan: ScheduleResult; parents: Lookup }) {
  const { feature, tasks, ws, plan, parents } = props;
  const s = featureSummary(feature, ws, plan);
  return (
    <Card>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-border px-4 py-3">
        <Link href={`/features/${feature.id}`} className="flex min-w-0 items-baseline gap-2 hover:underline">
          <span className="font-mono text-xs text-muted">{feature.id}</span>
          <span className="font-medium">{feature.title}</span>
        </Link>
        <PriorityBadge priority={s.priority} inherited={!feature.priority} />
        <Badge tone="muted">{feature.status.replace("_", " ")}</Badge>
        <div className="ml-auto">
          <Outlook data={s} />
        </div>
      </div>
      {tasks.length ? (
        <TaskTable tasks={tasks} plan={plan} parents={parents} />
      ) : (
        <p className="px-4 py-3 text-sm text-muted">No tasks — ask your agent to break down {feature.id}.</p>
      )}
    </Card>
  );
}

export default async function BacklogPage({ searchParams }: { searchParams: Promise<{ closed?: string }> }) {
  const { closed } = await searchParams;
  const showClosed = closed === "1";
  const ws = await loadWorkspace();
  const plan = scheduleFor(ws);
  const parents = lookup(ws.features, ws.projects);
  const tasks = ws.tasks.filter((t) => showClosed || isOpen(t.status));
  const features = ws.features
    .filter((f) => showClosed || isOpen(f.status))
    .sort((a, b) => PRIORITIES.indexOf(featureSummary(a, ws, plan).priority) - PRIORITIES.indexOf(featureSummary(b, ws, plan).priority));
  const projects = ws.projects
    .filter((p) => showClosed || isOpen(p.status))
    .sort((a, b) => PRIORITIES.indexOf(a.priority) - PRIORITIES.indexOf(b.priority));

  const projectIds = new Set(ws.projects.map((p) => p.id));
  const featureIds = new Set(ws.features.map((f) => f.id));
  const noProject = features.filter((f) => !f.project || !projectIds.has(f.project));
  const noFeature = tasks.filter((t) => !t.feature || !featureIds.has(t.feature));
  const card = (f: Feature) => (
    <FeatureCard key={f.id} feature={f} tasks={tasks.filter((t) => t.feature === f.id)} ws={ws} plan={plan} parents={parents} />
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h1 className="text-xl font-semibold tracking-tight">Backlog</h1>
        <Link href={showClosed ? "/backlog" : "/backlog?closed=1"} className="text-sm text-accent hover:underline">
          {showClosed ? "Hide done & cancelled" : "Show done & cancelled"}
        </Link>
      </div>

      {!projects.length && !features.length && !tasks.length && <Empty>Nothing here yet.</Empty>}

      {projects.map((project) => {
        const own = features.filter((f) => f.project === project.id);
        return (
          <section key={project.id} className="space-y-3">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <Link href={`/projects/${project.id}`} className="flex items-baseline gap-2 hover:underline">
                <span className="font-mono text-xs text-muted">{project.id}</span>
                <span className="text-lg font-semibold tracking-tight">{project.title}</span>
              </Link>
              <PriorityBadge priority={project.priority} />
              {project.status !== "active" && <Badge tone={project.status === "on_hold" ? "warn" : "muted"}>{project.status.replace("_", " ")}</Badge>}
              <div className="ml-auto">
                <Outlook data={projectSummary(project, ws, plan)} />
              </div>
            </div>
            {own.length ? own.map(card) : <p className="text-sm text-muted">No features — ask your agent to plan {project.id}.</p>}
          </section>
        );
      })}

      {noProject.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold tracking-tight text-muted">No project</h2>
          {noProject.map(card)}
        </section>
      )}

      {noFeature.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold tracking-tight text-muted">No feature</h2>
          <Card>
            <TaskTable tasks={noFeature} plan={plan} parents={parents} />
          </Card>
        </section>
      )}
    </div>
  );
}
