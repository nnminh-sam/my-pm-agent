import Link from "next/link";
import { notFound } from "next/navigation";
import { Outlook } from "@/components/outlook";
import { Badge, Card, Markdown, PriorityBadge, Stat, hours } from "@/components/ui";
import { featureSummary, projectSummary, scheduleFor } from "@/lib/planning";
import { NotFoundError, getProject, loadWorkspace } from "@/lib/repo";
import { fmtDay } from "@/lib/time";

export const dynamic = "force-dynamic";

export default async function ProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const project = await getProject(id).catch((err) => {
    if (err instanceof NotFoundError) notFound();
    throw err;
  });
  const ws = await loadWorkspace();
  const plan = scheduleFor(ws);
  const s = projectSummary(project, ws, plan);
  const features = ws.features.filter((f) => f.project === project.id).map((f) => ({ feature: f, summary: featureSummary(f, ws, plan) }));
  const onHold = project.status === "on_hold";

  return (
    <div className="space-y-6">
      <div>
        <div className="flex flex-wrap items-center gap-2 text-sm">
          <Link href="/projects" className="text-muted hover:underline">
            Projects
          </Link>
          <span className="text-muted">/</span>
          <span className="font-mono text-muted">{project.id}</span>
          <PriorityBadge priority={project.priority} />
          <Badge tone={onHold ? "warn" : "muted"}>{project.status.replace("_", " ")}</Badge>
        </div>
        <h1 className="mt-1 text-xl font-semibold tracking-tight">{project.title}</h1>
      </div>

      {onHold && (
        <div className="rounded-xl bg-warn-soft px-4 py-3 text-sm text-warn">
          This project is on hold, so none of its tasks are on the schedule.
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Estimate" value={`${hours(s.estimate_hours)}${s.estimate_sd_hours ? ` ±${hours(s.estimate_sd_hours)}` : ""}`} />
        <Stat label="Remaining" value={hours(s.remaining_hours)} />
        <Stat
          label={project.deadline ? `Done by (due ${fmtDay(project.deadline)})` : "Done by"}
          value={s.projected_finish ? fmtDay(s.projected_finish) : "—"}
          tone={s.on_track === false ? "danger" : s.on_track ? "ok" : undefined}
        />
        <Stat label="Progress" value={`${Math.round(s.progress * 100)}%`} />
      </div>

      <Card className="px-5 py-4">
        <h2 className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">About</h2>
        <Markdown>{project.body}</Markdown>
      </Card>

      <Card>
        <h2 className="border-b border-border px-4 py-2.5 font-medium">
          Features <span className="text-sm font-normal text-muted">({features.length})</span>
        </h2>
        {features.length ? (
          <ul className="divide-y divide-border">
            {features.map(({ feature, summary }) => (
              <li key={feature.id} className="flex flex-wrap items-center gap-x-4 gap-y-1.5 px-4 py-3">
                <Link href={`/features/${feature.id}`} className="flex min-w-0 flex-1 items-baseline gap-2 hover:underline">
                  <span className="font-mono text-xs text-muted">{feature.id}</span>
                  <span className="truncate">{feature.title}</span>
                </Link>
                <PriorityBadge priority={summary.priority} inherited={!feature.priority} />
                <Badge tone="muted">{feature.status.replace("_", " ")}</Badge>
                <span className="text-xs text-muted">
                  {summary.tasks} task{summary.tasks === 1 ? "" : "s"}
                </span>
                <Outlook data={summary} />
              </li>
            ))}
          </ul>
        ) : (
          <p className="px-4 py-3 text-sm text-muted">
            No features yet. Ask your agent: “plan {project.id}” (breakdown_project prompt).
          </p>
        )}
      </Card>
    </div>
  );
}
