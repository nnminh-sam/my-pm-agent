import { createHash } from "node:crypto";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { Client } from "@neondatabase/serverless";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { neonDb, type Db, type Row } from "./db";
import { migrate, type MigrationSession } from "./migrate";
import * as repo from "./repo";
import { setRepository, type Repository } from "./repository";
import { FileRepository } from "./repository/file";
import { PgRepository } from "./repository/postgres";
import { FsStore } from "./store/fs";
import { todayIn } from "./time";
import { compareBackends, exportTo, importInto, readAll } from "./transfer";

const tempDirs: string[] = [];
async function tempDir() {
  const dir = await mkdtemp(path.join(tmpdir(), "my-pm-"));
  tempDirs.push(dir);
  return dir;
}
afterAll(async () => {
  setRepository(undefined);
  await Promise.all(tempDirs.map((dir) => rm(dir, { recursive: true, force: true })));
});

async function pglite(): Promise<PgRepository> {
  const pg = new PGlite();
  await migrate({
    exec: async (sql) => {
      await pg.exec(sql);
    },
    query: async (text, params) => (await pg.query<Row>(text, params)).rows,
  });
  const db: Db = {
    query: async (text, params) => (await pg.query<Row>(text, params)).rows,
    transaction: (statements) =>
      pg.transaction(async (tx) => {
        const results: Row[][] = [];
        for (const s of statements) results.push((await tx.query<Row>(s.text, s.params)).rows);
        return results;
      }),
  };
  return new PgRepository(db);
}

/** A real Neon database, only when TEST_DATABASE_URL points at a disposable branch. It is wiped first. */
async function neonTestDb(url: string): Promise<PgRepository> {
  const client = new Client(url);
  await client.connect();
  const session: MigrationSession = {
    exec: async (sql) => {
      await client.query(sql);
    },
    query: async (text, params) => (await client.query(text, params)).rows,
  };
  try {
    await migrate(session);
    await session.exec("truncate tasks, features, projects, settings, users, api_keys restart identity");
  } finally {
    await client.end();
  }
  return new PgRepository(neonDb(url));
}

const backends: { name: string; setup: () => Promise<Repository>; dir?: string }[] = [
  {
    name: "fs",
    async setup() {
      const dir = await tempDir();
      this.dir = dir;
      return new FileRepository(new FsStore(dir));
    },
  },
  { name: "postgres (pglite)", setup: pglite },
];
const testDatabaseUrl = process.env.TEST_DATABASE_URL;
if (testDatabaseUrl) backends.push({ name: "postgres (neon)", setup: () => neonTestDb(testDatabaseUrl) });

describe.each(backends)("$name backend", (backend) => {
  let backendRepo: Repository;
  beforeAll(async () => {
    backendRepo = await backend.setup();
    setRepository(backendRepo);
  });

  describe("project → feature → task", () => {
    it("creates the hierarchy and loads it back", async () => {
      const project = await repo.createProject({ title: "Website relaunch", priority: "P1", description: "## Goal\nShip v2." });
      expect(project.id).toBe("PRJ-1");

      const feature = await repo.createFeature({ title: "Login", project: "1" });
      expect(feature).toMatchObject({ id: "F-1", project: "PRJ-1", priority: undefined });

      const [task] = await repo.createTasks([{ title: "POST /login", feature: "F-1", estimate: 2 }]);
      expect(task).toMatchObject({ id: "T-1", feature: "F-1" });

      if (backend.dir) {
        const text = await readFile(path.join(backend.dir, "projects/PRJ-1.md"), "utf8");
        expect(text).toContain("id: PRJ-1\ntitle: Website relaunch\nstatus: active\npriority: P1");
        expect(text).toContain("## Goal\nShip v2.");
      }

      const ws = await repo.loadWorkspace();
      expect(ws.projects.map((p) => p.id)).toEqual(["PRJ-1"]);
      expect(ws.projects[0].body).toBe("## Goal\nShip v2.");
      expect(ws.features[0].project).toBe("PRJ-1");
      expect(ws.tasks).toEqual([task]);
      expect(ws.problems).toEqual([]);
    });

    it("rejects features in unknown projects and can move a feature out of a project", async () => {
      await expect(repo.createFeature({ title: "Orphan", project: "PRJ-9" })).rejects.toThrow("Project PRJ-9 not found");
      const moved = await repo.updateFeature("F-1", { project: null, priority: "P2" });
      expect(moved).toMatchObject({ project: undefined, priority: "P2" });
      const back = await repo.updateFeature("F-1", { project: "PRJ-1", priority: null });
      expect(back).toMatchObject({ project: "PRJ-1", priority: undefined });
      expect(await repo.getFeature("f-1")).toEqual(back);
    });

    it("puts a project on hold", async () => {
      const project = await repo.updateProject("PRJ-1", { status: "on_hold", deadline: "2026-12-01" });
      expect(project).toMatchObject({ status: "on_hold", deadline: "2026-12-01" });
      expect((await repo.getProject("prj-1")).status).toBe("on_hold");
      await expect(repo.getProject("PRJ-7")).rejects.toBeInstanceOf(repo.NotFoundError);
    });
  });

  describe("tasks", () => {
    it("resolves backward and forward refs within a batch", async () => {
      const created = await repo.createTasks([
        { ref: "api", title: "API", feature: "F-1", depends_on: ["ui", "T-1"], pert: { optimistic: 1, likely: 2, pessimistic: 6 } },
        { ref: "ui", title: "UI", feature: "F-1", tags: ["frontend"], deadline: "2026-11-01" },
        { title: "Docs", depends_on: ["api"] },
      ]);
      expect(created.map((t) => t.id)).toEqual(["T-2", "T-3", "T-4"]);
      // Existing ids and earlier refs first, forward refs last.
      expect(created[0].depends_on).toEqual(["T-1", "T-3"]);
      expect(created[2].depends_on).toEqual(["T-2"]);
      expect(created[0]).toMatchObject({ estimate: 2.5, estimate_range: [1, 6] });
      expect(await repo.getTask("T-2")).toEqual(created[0]);
      expect(await repo.getTask("3")).toEqual(created[1]);
    });

    it("rejects a batch with a bad dependency or a cycle and writes nothing", async () => {
      const before = (await repo.loadWorkspace()).tasks.length;
      await expect(
        repo.createTasks([{ title: "ok", feature: "F-1" }, { title: "bad", depends_on: ["T-99"] }]),
      ).rejects.toThrow("T-99");
      await expect(
        repo.createTasks([
          { ref: "a", title: "a", depends_on: ["b"] },
          { ref: "b", title: "b", depends_on: ["a"] },
        ]),
      ).rejects.toThrow("cycle");
      expect((await repo.loadWorkspace()).tasks.length).toBe(before);
    });

    it("updates fields, completes and reopens a task", async () => {
      const updated = await repo.updateTask("T-3", { estimate: 4, priority: "P0", not_before: "2026-10-01", append_note: "hi" });
      expect(updated).toMatchObject({ estimate: 4, estimate_range: undefined, priority: "P0", not_before: "2026-10-01" });
      expect(updated.body).toMatch(/### Note · \d{4}-\d{2}-\d{2}\n\nhi$/);
      const done = await repo.updateTask("T-3", { status: "done" });
      expect(done.completed).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      const reopened = await repo.updateTask("T-3", { status: "todo", priority: null, not_before: null });
      expect(reopened).toMatchObject({ completed: undefined, priority: undefined, not_before: undefined });
      expect(await repo.getTask("T-3")).toEqual(reopened);
      await expect(repo.updateTask("T-1", { depends_on: ["T-2"] })).rejects.toThrow("cycle");
    });

    it("logs time into the ## Log section", async () => {
      const first = await repo.logTime("T-1", 1.5, "skeleton");
      expect(first).toMatchObject({ spent: 1.5, status: "in_progress" });
      const second = await repo.logTime("T-1", 0.25, undefined, true);
      expect(second).toMatchObject({ spent: 1.75, status: "done" });
      expect(second.body).toMatch(/## Log\n\n- \d{4}-\d{2}-\d{2}: 1.5h — skeleton\n- \d{4}-\d{2}-\d{2}: 0.25h$/);
      expect(await repo.getTask("T-1")).toEqual(second);
    });

    it("reorders tasks", async () => {
      const reordered = await repo.reorderTasks(["T-4", "T-2"]);
      expect(reordered.map((t) => [t.id, t.order])).toEqual([["T-4", 0], ["T-2", 1]]);
      expect((await repo.getTask("T-2")).order).toBe(1);
      await expect(repo.reorderTasks(["T-2", "T-99"])).rejects.toThrow("Task T-99 not found");
      expect((await repo.getTask("T-2")).order).toBe(1);
    });

    it("saves settings without resetting unmentioned fields", async () => {
      await repo.updateSettings({ timezone: "Asia/Ho_Chi_Minh", buffer: 1.2 });
      const settings = await repo.updateSettings({ days_off: ["2026-12-25"] });
      expect(settings).toMatchObject({ timezone: "Asia/Ho_Chi_Minh", buffer: 1.2, days_off: ["2026-12-25"] });
      expect(await repo.getSettings()).toEqual(settings);
    });
  });

  describe("users", () => {
    const hash = "scrypt$16384$8$1$c2FsdA$aGFzaA";

    it("creates a user and finds it by email, case-insensitively", async () => {
      expect(await repo.countUsers()).toBe(0);
      const user = await repo.createUser({ email: "  Me@Example.COM ", password_hash: hash });
      const today = todayIn((await repo.getSettings()).timezone);
      expect(user).toEqual({ id: "U-1", email: "me@example.com", password_hash: hash, created: today });
      expect(await repo.findUserByEmail("ME@example.com")).toEqual(user);
      expect(await repo.findUserByEmail(" me@example.com")).toEqual(user);
      expect(await repo.findUserByEmail("other@example.com")).toBeNull();
      expect(await repo.getUser("U-1")).toEqual(user);
      expect(await repo.getUser("u-1")).toEqual(user);
      expect(await repo.getUser("U-9")).toBeNull();
      expect(await repo.countUsers()).toBe(1);
      if (backend.dir) {
        const text = await readFile(path.join(backend.dir, "users/U-1.md"), "utf8");
        expect(text).toBe(`---\nid: U-1\nemail: me@example.com\npassword_hash: ${hash}\ncreated: ${today}\n---\n`);
      }
    });

    it("returns null for a duplicate email and keeps the original", async () => {
      expect(await repo.createUser({ email: "ME@EXAMPLE.com", password_hash: "other" })).toBeNull();
      expect(await repo.countUsers()).toBe(1);
      expect((await repo.findUserByEmail("me@example.com"))?.password_hash).toBe(hash);
    });

    it("throws on an invalid email and writes nothing", async () => {
      for (const email of ["", "   ", "me", "me@example", "@example.com", "me@.com", "me @example.com", "me@exa mple.com", "a@b@c.com"]) {
        await expect(repo.createUser({ email, password_hash: hash })).rejects.toThrow("Invalid email address");
      }
      await expect(repo.createUser({ email: `${"a".repeat(250)}@b.co`, password_hash: hash })).rejects.toThrow("Invalid email address");
      expect(await repo.countUsers()).toBe(1);
    });

    it("increments ids", async () => {
      const two = await repo.createUser({ email: "two@example.com", password_hash: hash });
      const three = await repo.createUser({ email: "three@example.com", password_hash: hash });
      expect([two?.id, three?.id]).toEqual(["U-2", "U-3"]);
      expect(await repo.countUsers()).toBe(3);
      expect(await repo.getUser("3")).toEqual(three);
    });

    it("rejects a duplicate at the backend too", async () => {
      const draft = { email: "two@example.com", password_hash: "x", created: "2026-09-27" };
      expect(await backendRepo.insertUser(draft)).toBeNull();
      expect(await backendRepo.countUsers()).toBe(3);
    });

    it("keeps users out of the workspace", async () => {
      const records = await backendRepo.loadAll();
      expect(Object.keys(records).sort()).toEqual(["features", "problems", "projects", "tasks"]);
      expect(records.problems).toEqual([]);
      const ws = await repo.loadWorkspace();
      const ids = [...ws.tasks, ...ws.features, ...ws.projects].map((r) => r.id);
      expect(ids.filter((id) => id.startsWith("U-"))).toEqual([]);
      expect(JSON.stringify(await readAll(backendRepo))).not.toContain("example.com");
    });
  });

  describe("api keys", () => {
    const sha = (s: string) => createHash("sha256").update(s).digest("hex");
    const [h1, h2, h3] = [sha("one"), sha("two"), sha("three")];

    it("creates keys by hash and finds them by hash", async () => {
      expect(await repo.listApiKeys()).toEqual([]);
      const key = await repo.createApiKey({ label: "  laptop ", hash: h1 });
      const today = todayIn((await repo.getSettings()).timezone);
      expect(key).toEqual({ id: "K-1", label: "laptop", hash: h1, created: today });
      expect(await repo.findApiKeyByHash(h1)).toEqual(key);
      expect(await repo.findApiKeyByHash(h2)).toBeNull();
      expect(await repo.findApiKeyByHash("not-a-hash")).toBeNull();
      expect(await repo.getApiKey("k-1")).toEqual(key);
      expect(await repo.getApiKey("K-9")).toBeNull();
      expect(await repo.getApiKey("../users/U-1")).toBeNull();
      if (backend.dir) {
        const text = await readFile(path.join(backend.dir, "api_keys/K-1.md"), "utf8");
        expect(text).toBe(`---\nid: K-1\nlabel: laptop\nhash: ${h1}\ncreated: ${today}\n---\n`);
      }
    });

    it("rejects anything but a lowercase hex SHA-256 and writes nothing", async () => {
      for (const hash of ["", "abc", h2.toUpperCase(), `${h2}0`, h2.replace(/./, "g")]) {
        await expect(repo.createApiKey({ label: "x", hash })).rejects.toThrow("SHA-256");
      }
      expect((await repo.listApiKeys()).map((k) => k.id)).toEqual(["K-1"]);
    });

    it("lists keys by id number, with empty labels", async () => {
      const two = await repo.createApiKey({ label: "", hash: h2 });
      const three = await repo.createApiKey({ hash: h3 });
      expect([two.id, three.id, two.label, three.label]).toEqual(["K-2", "K-3", "", ""]);
      expect((await repo.listApiKeys()).map((k) => k.id)).toEqual(["K-1", "K-2", "K-3"]);
      expect(await repo.findApiKeyByHash(h3)).toEqual(three);
    });

    it("touches last_used_at", async () => {
      const at = new Date("2026-09-27T02:03:04.567Z");
      const touched = await repo.touchApiKey("K-2", at);
      expect(touched).toMatchObject({ id: "K-2", last_used_at: "2026-09-27T02:03:04.567Z" });
      expect(touched?.revoked_at).toBeUndefined();
      expect(await repo.findApiKeyByHash(h2)).toEqual(touched);
      expect(await repo.touchApiKey("K-99")).toBeNull();
    });

    it("revokes idempotently and keeps revoked keys listed", async () => {
      const at = new Date("2026-09-27T03:00:00.000Z");
      const revoked = await repo.revokeApiKey("2", at);
      expect(revoked).toMatchObject({ id: "K-2", last_used_at: "2026-09-27T02:03:04.567Z", revoked_at: at.toISOString() });
      expect(await repo.revokeApiKey("K-2", new Date("2026-10-01T00:00:00.000Z"))).toEqual(revoked);
      expect(await repo.getApiKey("K-2")).toEqual(revoked);
      expect(await repo.findApiKeyByHash(h2)).toEqual(revoked);
      expect(await repo.revokeApiKey("K-99")).toBeNull();
      expect(await repo.revokeApiKey("nope")).toBeNull();
      const list = await repo.listApiKeys();
      expect(list.map((k) => [k.id, Boolean(k.revoked_at)])).toEqual([["K-1", false], ["K-2", true], ["K-3", false]]);
    });

    it("touches only last_used_at, so a touch after a revoke keeps revoked_at", async () => {
      const revoked = (await repo.getApiKey("K-2"))!;
      expect(revoked.revoked_at).toBe("2026-09-27T03:00:00.000Z");
      const at = new Date("2026-09-27T04:05:06.789Z");
      const touched = await repo.touchApiKey("K-2", at);
      expect(touched).toEqual({ ...revoked, last_used_at: at.toISOString() });
      expect(await repo.getApiKey("K-2")).toEqual(touched);
      expect(await repo.findApiKeyByHash(h2)).toEqual(touched);
      // Straight to the repository too, and junk ids never reach it.
      expect(await backendRepo.touchApiKey("K-99", at.toISOString())).toBeNull();
      expect(await repo.touchApiKey("../users/U-1", at)).toBeNull();
    });

    it("stores the owning user and lists an account's keys", async () => {
      const [u1, u2] = [(await repo.findUserByEmail("me@example.com"))!, (await repo.findUserByEmail("two@example.com"))!];
      const mine = await repo.createApiKey({ label: "web", hash: sha("mine"), user_id: u1.id });
      const theirs = await repo.createApiKey({ hash: sha("theirs"), user_id: u2.id.toLowerCase() });
      expect(mine.user_id).toBe(u1.id);
      expect(theirs.user_id).toBe(u2.id);
      expect(await repo.findApiKeyByHash(sha("mine"))).toEqual(mine);
      expect((await repo.listUserApiKeys(u1.id)).map((k) => k.id)).toEqual([mine.id]);
      expect((await repo.listUserApiKeys(u2.id)).map((k) => k.id)).toEqual([theirs.id]);
      // CLI keys (no owner) belong to no account.
      expect((await repo.getApiKey("K-1"))?.user_id).toBeUndefined();
      // Revoking and touching keep the owner.
      const revoked = await repo.revokeApiKey(mine.id, new Date("2026-09-27T05:00:00.000Z"));
      expect(revoked?.user_id).toBe(u1.id);
      expect((await repo.touchApiKey(mine.id))?.user_id).toBe(u1.id);
    });

    it("keeps API keys out of the workspace", async () => {
      const records = await backendRepo.loadAll();
      expect(Object.keys(records).sort()).toEqual(["features", "problems", "projects", "tasks"]);
      expect(records.problems).toEqual([]);
      const dump = JSON.stringify(await readAll(backendRepo));
      for (const hash of [h1, h2, h3]) expect(dump).not.toContain(hash);
      expect(dump).not.toContain('"K-');
    });
  });
});

describe("email helpers", () => {
  it("normalizes and validates", () => {
    expect(repo.normalizeEmail("  Me@Example.COM\n")).toBe("me@example.com");
    expect(repo.isValidEmail("a@b.co")).toBe(true);
    expect(repo.isValidEmail("first.last+tag@sub.example.com")).toBe(true);
    expect(repo.isValidEmail(" a@b.co")).toBe(false);
    expect(repo.isValidEmail("a@b")).toBe(false);
    expect(repo.isValidEmail(`${"a".repeat(249)}@b.com`)).toBe(false);
    expect(repo.isValidEmail(`${"a".repeat(248)}@b.com`)).toBe(true);
  });
});

describe("postgres specifics", () => {
  it("rolls back a whole task batch when the database rejects one row", async () => {
    const pg = await pglite();
    setRepository(pg);
    await repo.createProject({ title: "P" });
    await expect(
      pg.insertTasks([
        { title: "ok", status: "todo", spent: 0, depends_on: [], tags: [], created: "2026-09-27", body: "" },
        { title: "orphan", status: "todo", feature: "F-404", spent: 0, depends_on: [], tags: [], created: "2026-09-27", body: "" },
      ]),
    ).rejects.toThrow();
    expect((await pg.loadAll()).tasks).toEqual([]);
  });
});

describe("import / export", () => {
  let source: FileRepository;

  beforeAll(async () => {
    const dir = await tempDir();
    source = new FileRepository(new FsStore(dir));
    setRepository(source);
    await repo.updateSettings({ timezone: "Asia/Ho_Chi_Minh" });
    await repo.createProject({ title: "P", deadline: "2026-12-01", description: "Goal" });
    await repo.createFeature({ title: "F", project: "PRJ-1", priority: "P1" });
    await repo.createTasks([
      { ref: "a", title: "A", feature: "F-1", pert: { optimistic: 1, likely: 2, pessimistic: 4 }, tags: ["x"], depends_on: ["b"] },
      { ref: "b", title: "B", feature: "F-1", estimate: 3, not_before: "2026-10-01" },
      { title: "C", feature: "F-1", estimate: 1, status: "blocked" },
    ]);
    await repo.logTime("T-2", 1, "started");
    await repo.reorderTasks(["T-3", "T-1"]);
    // Leave a gap in the ids: T-4 exists, T-5 doesn't, T-6 does.
    await repo.createTasks([{ title: "D" }, { title: "E" }, { title: "F" }]);
    await rm(path.join(dir, "tasks/T-5.md"));
    // Users are never transferred.
    await repo.createUser({ email: "me@example.com", password_hash: "hash" });
    // Nor are API keys.
    await repo.createApiKey({ label: "agent", hash: "a".repeat(64) });
  });

  it("imports markdown into Postgres with identical workspace and schedule, and continues ids", async () => {
    const pg = await pglite();
    await importInto(pg, source);
    expect(await compareBackends(source, pg)).toEqual([]);
    expect(await pg.countUsers()).toBe(0);
    expect(await pg.listApiKeys()).toEqual([]);

    await expect(importInto(pg, source)).rejects.toThrow("not empty");
    const user = await pg.insertUser({ email: "pg@example.com", password_hash: "hash", created: "2026-09-27" });
    const key = await pg.insertApiKey({ label: "pg", hash: "b".repeat(64), created: "2026-09-27" });
    await importInto(pg, source, { replace: true });
    expect(await compareBackends(source, pg)).toEqual([]);
    expect(await pg.getUser("U-1")).toEqual(user);
    expect(await pg.listApiKeys()).toEqual([key]);
    expect(await pg.countUsers()).toBe(1);

    setRepository(pg);
    const [next] = await repo.createTasks([{ title: "after import" }]);
    expect(next.id).toBe("T-7");
    expect((await repo.createFeature({ title: "F2" })).id).toBe("F-2");
    expect((await repo.createProject({ title: "P2" })).id).toBe("PRJ-2");
  });

  it("round-trips: markdown → Postgres → markdown", async () => {
    const pg = await pglite();
    await importInto(pg, source);
    const exported = new FileRepository(new FsStore(await tempDir()));
    await exportTo(exported, pg);
    expect(await compareBackends(source, exported)).toEqual([]);
    expect(await exported.countUsers()).toBe(0);
    expect(await exported.listApiKeys()).toEqual([]);
  });
});
