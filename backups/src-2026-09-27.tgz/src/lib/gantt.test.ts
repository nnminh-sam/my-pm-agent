import { describe, expect, it } from "vitest";
import { featureOptions, ganttRange, ganttRows, NO_FEATURE, NO_PROJECT, parseGanttQuery } from "./gantt";
import { schedule } from "./scheduler";
import { FeatureMeta, ProjectMeta, Settings, TaskMeta } from "./types";

const settings = Settings.parse({ timezone: "UTC" }); // Mon–Fri 09–12, 13–17 (7h/day)
const MONDAY = "2026-09-28";
const TUESDAY = "2026-09-29";

const projects = [
  ProjectMeta.parse({ id: "PRJ-1", title: "Alpha", priority: "P1", created: "2026-09-01" }),
  ProjectMeta.parse({ id: "PRJ-2", title: "Beta", priority: "P2", created: "2026-09-01" }),
];
const features = [
  FeatureMeta.parse({ id: "F-1", title: "Login", project: "PRJ-1", created: "2026-09-01" }),
  FeatureMeta.parse({ id: "F-2", title: "Billing", project: "PRJ-1", created: "2026-09-01" }),
  FeatureMeta.parse({ id: "F-3", title: "Docs", project: "PRJ-2", created: "2026-09-01" }),
];
const t = (id: string, feature: string | undefined, estimate: number, extra: Partial<TaskMeta> = {}) =>
  TaskMeta.parse({ id, title: `Task ${id}`, feature, estimate, created: "2026-09-01", ...extra });

const tasks = [t("T-1", "F-1", 4), t("T-2", "F-1", 4), t("T-3", "F-2", 3), t("T-4", "F-3", 2)];
const plan = schedule({ tasks, features, projects, settings, now: { date: MONDAY, minutes: 8 * 60 } });
const ids = (rows: ReturnType<typeof ganttRows>) => rows.flatMap((p) => p.features.flatMap((f) => f.tasks.map((x) => x.id)));

describe("ganttRows", () => {
  it("groups Project → Feature → Task and keeps the scheduler's order with no filters", () => {
    const rows = ganttRows(plan, { features, projects });
    expect(rows.map((p) => [p.id, p.title])).toEqual([
      ["PRJ-1", "Alpha"],
      ["PRJ-2", "Beta"],
    ]);
    expect(rows[0].features.map((f) => [f.id, f.tasks.map((x) => x.id)])).toEqual([
      ["F-1", ["T-1", "T-2"]],
      ["F-2", ["T-3"]],
    ]);
    expect(ids(rows)).toEqual(plan.tasks.map((x) => x.id));
  });

  it("carries work blocks, span, priority and deadline flags straight from the schedule", () => {
    const late = t("T-9", "F-3", 10, { priority: "P0", deadline: MONDAY });
    const p = schedule({ tasks: [late], features, projects, settings, now: { date: MONDAY, minutes: 8 * 60 } });
    const [task] = ganttRows(p, { features, projects })[0].features[0].tasks;
    expect(task.blocks).toEqual(p.days.flatMap((d) => d.blocks));
    expect(task.start).toEqual(p.tasks[0].start);
    expect(task.end).toEqual(p.tasks[0].end);
    expect(task.priority).toBe("P0");
    expect(task.deadline).toBe(MONDAY);
    expect(task.at_risk).toBe(true);
    expect(task.late_days).toBeGreaterThan(0);

    const ontime = ganttRows(plan, { features, projects })[0].features[0].tasks[0];
    expect(ontime.at_risk).toBe(false);
    expect(ontime.late_days).toBe(0);
  });

  it("follows the scheduler when a later project's task goes first", () => {
    const urgent = [...tasks, t("T-5", "F-3", 1, { priority: "P0" })];
    const p = schedule({ tasks: urgent, features, projects, settings, now: { date: MONDAY, minutes: 8 * 60 } });
    const rows = ganttRows(p, { features, projects });
    expect(rows.map((r) => r.id)).toEqual(["PRJ-2", "PRJ-1"]);
    expect(rows[0].features[0].tasks.map((x) => x.id)).toEqual(["T-5", "T-4"]);
  });

  it("filters by project", () => {
    expect(ids(ganttRows(plan, { features, projects }, { projects: ["PRJ-2"] }))).toEqual(["T-4"]);
    expect(ids(ganttRows(plan, { features, projects }, { projects: ["PRJ-1"] }))).toEqual(["T-1", "T-2", "T-3"]);
  });

  it("filters by feature (several at once)", () => {
    expect(ids(ganttRows(plan, { features, projects }, { features: ["F-2"] }))).toEqual(["T-3"]);
    expect(ids(ganttRows(plan, { features, projects }, { features: ["F-2", "F-3"] }))).toEqual(["T-3", "T-4"]);
  });

  it("treats empty filter lists as no filter", () => {
    expect(ids(ganttRows(plan, { features, projects }, { projects: [], features: [] }))).toEqual(["T-1", "T-2", "T-3", "T-4"]);
  });

  it("filters by date range, dropping tasks with no work in it", () => {
    // Monday holds T-1 (4h) and the first 3h of T-2; Tuesday holds the rest.
    expect(ids(ganttRows(plan, { features, projects }, { from: MONDAY, to: MONDAY }))).toEqual(["T-1", "T-2"]);
    expect(ids(ganttRows(plan, { features, projects }, { from: TUESDAY }))).toEqual(["T-2", "T-3", "T-4"]);
    expect(ganttRows(plan, { features, projects }, { from: "2027-01-01" })).toEqual([]);
  });

  it("clips a task's blocks to the range but keeps its full scheduled span", () => {
    const all = ganttRows(plan, { features, projects })[0].features[0].tasks[1]; // T-2 spans Mon + Tue
    expect(all.blocks.map((b) => b.date)).toEqual([MONDAY, TUESDAY]);

    const clipped = ganttRows(plan, { features, projects }, { from: TUESDAY })[0].features[0].tasks[0];
    expect(clipped.id).toBe("T-2");
    expect(clipped.blocks.map((b) => b.date)).toEqual([TUESDAY]);
    expect(clipped.start).toEqual(all.start);
    expect(clipped.end).toEqual(all.end);
  });

  it("combines filters with AND", () => {
    const f = { projects: ["PRJ-1"], features: ["F-1"], from: TUESDAY, to: TUESDAY };
    expect(ids(ganttRows(plan, { features, projects }, f))).toEqual(["T-2"]);
    // feature outside the selected project → nothing
    expect(ganttRows(plan, { features, projects }, { projects: ["PRJ-2"], features: ["F-1"] })).toEqual([]);
  });

  it("puts tasks without a feature or project under placeholder groups, and hides them when filtering by project", () => {
    const loose = t("T-7", undefined, 1);
    const orphan = t("T-8", "F-9", 1);
    const p = schedule({
      tasks: [loose, orphan],
      features: [...features, FeatureMeta.parse({ id: "F-9", title: "Loose", created: "2026-09-01" })],
      projects,
      settings,
      now: { date: MONDAY, minutes: 8 * 60 },
    });
    const ws = { features: [...features, FeatureMeta.parse({ id: "F-9", title: "Loose", created: "2026-09-01" })], projects };
    const rows = ganttRows(p, ws);
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ id: undefined, title: NO_PROJECT });
    expect(rows[0].features.map((f) => [f.id, f.title])).toEqual([
      [undefined, NO_FEATURE],
      ["F-9", "Loose"],
    ]);
    expect(ganttRows(p, ws, { projects: ["PRJ-1"] })).toEqual([]);
  });

  it("omits tasks the scheduler left out", () => {
    const held = [...projects.slice(0, 1), ProjectMeta.parse({ id: "PRJ-2", title: "Beta", status: "on_hold", created: "2026-09-01" })];
    const p = schedule({ tasks, features, projects: held, settings, now: { date: MONDAY, minutes: 8 * 60 } });
    expect(ids(ganttRows(p, { features, projects: held }))).toEqual(["T-1", "T-2", "T-3"]);
  });
});

describe("ganttRange", () => {
  const rows = ganttRows(plan, { features, projects });
  it("spans the plan and today, unless the filters set the bounds", () => {
    const r = ganttRange(rows, "2026-09-20");
    expect(r.from).toBe("2026-09-20");
    expect(r.to).toBe(TUESDAY);
    expect(ganttRange(rows, "2026-10-30")).toEqual({ from: MONDAY, to: "2026-10-30" });
    expect(ganttRange(rows, MONDAY, { from: "2026-10-01", to: "2026-10-05" })).toEqual({ from: "2026-10-01", to: "2026-10-05" });
    expect(ganttRange(rows, MONDAY, { from: "2026-12-01" })).toEqual({ from: "2026-12-01", to: "2026-12-01" });
    expect(ganttRange([], MONDAY)).toEqual({ from: MONDAY, to: MONDAY });
  });
});

describe("featureOptions / parseGanttQuery", () => {
  it("narrows feature choices by the selected projects", () => {
    expect(featureOptions(features, []).map((f) => f.id)).toEqual(["F-1", "F-2", "F-3"]);
    expect(featureOptions(features, ["PRJ-1"]).map((f) => f.id)).toEqual(["F-1", "F-2"]);
    expect(featureOptions(features, ["PRJ-1", "PRJ-2"]).map((f) => f.id)).toEqual(["F-1", "F-2", "F-3"]);
  });

  it("parses repeated params, validates dates and unit, and drops features outside the projects", () => {
    const q = parseGanttQuery(
      { project: "PRJ-1", feature: ["F-1", "F-3"], from: "2026-10-01", to: "nope", unit: "hour", at: "2026-09-29T09:30" },
      features,
    );
    expect(q.filters).toEqual({ projects: ["PRJ-1"], features: ["F-1"], from: "2026-10-01", to: undefined });
    expect(q.unit).toBe("hour");
    expect(q.at).toEqual({ date: TUESDAY, time: "09:30" });
  });

  it("defaults to the day unit and no filters", () => {
    const q = parseGanttQuery({ unit: "decade", at: "garbage" }, features);
    expect(q).toEqual({ filters: { projects: [], features: [], from: undefined, to: undefined }, unit: "day", at: undefined });
  });

  it("round-trips: the parsed filters select the same rows as the raw ones", () => {
    const { filters } = parseGanttQuery({ project: "PRJ-1", feature: "F-2" }, features);
    expect(ids(ganttRows(plan, { features, projects }, filters))).toEqual(["T-3"]);
  });
});
