import { lineage, lookup } from "./hierarchy";
import { UNITS, type Unit } from "./timescale";
import type { Block, ScheduleResult, ScheduledTask } from "./scheduler";
import { DATE, type FeatureMeta, type Priority, type ProjectMeta, type TaskMeta, type TaskStatus } from "./types";

/**
 * Pure mapping from a computed schedule to Gantt rows: Project → Feature → Task.
 * It only filters, groups and clips what the scheduler already decided — never reschedules.
 */

export interface GanttFilters {
  /** Project ids; empty/undefined = all. */
  projects?: string[];
  /** Feature ids; empty/undefined = all. Combined with `projects` as AND. */
  features?: string[];
  /** Inclusive YYYY-MM-DD bounds; blocks outside are dropped, tasks with no block left are hidden. */
  from?: string;
  to?: string;
}

export interface GanttTask {
  id: string;
  title: string;
  priority: Priority;
  /** "todo" when the workspace's tasks weren't passed in. */
  status: TaskStatus;
  /** Effective deadline (task, feature or project, whichever is earliest). */
  deadline?: string;
  /** Ids of tasks this one waits on (empty when the workspace's tasks weren't passed in). */
  depends_on: string[];
  /** The task's own estimate, when known. */
  estimate?: number;
  /** Hours the scheduler placed. */
  hours: number;
  /** Full scheduled span (not clipped by the date range). */
  start: ScheduledTask["start"];
  end: ScheduledTask["end"];
  /** Work blocks inside the date range, in time order. */
  blocks: Block[];
  late_days: number;
  /** Ends after its (inherited) deadline. */
  at_risk: boolean;
  pulled_forward: boolean;
}

export interface GanttFeature {
  /** undefined for tasks without a feature. */
  id?: string;
  title: string;
  /** The feature's own deadline, for its group row. */
  deadline?: string;
  tasks: GanttTask[];
}

export interface GanttProject {
  /** undefined for tasks whose feature has no project (or that have no feature). */
  id?: string;
  title: string;
  /** The project's own deadline, for its group row. */
  deadline?: string;
  features: GanttFeature[];
}

export const NO_PROJECT = "No project";
export const NO_FEATURE = "No feature";

export function ganttRows(
  plan: ScheduleResult,
  ws: { features: FeatureMeta[]; projects: ProjectMeta[]; tasks?: TaskMeta[] },
  filters: GanttFilters = {},
): GanttProject[] {
  const parents = lookup(ws.features, ws.projects);
  const meta = new Map((ws.tasks ?? []).map((t) => [t.id, t]));
  const projectIds = filters.projects?.length ? new Set(filters.projects) : undefined;
  const featureIds = filters.features?.length ? new Set(filters.features) : undefined;
  const { from, to } = filters;

  const blocksByTask = new Map<string, Block[]>();
  for (const day of plan.days) {
    if ((from && day.date < from) || (to && day.date > to)) continue;
    for (const block of day.blocks) {
      const list = blocksByTask.get(block.task);
      if (list) list.push(block);
      else blocksByTask.set(block.task, [block]);
    }
  }

  // Map preserves first-seen order, so groups follow the scheduler's task order.
  const projects = new Map<string, GanttProject>();
  const featureRows = new Map<string, GanttFeature>(); // keyed by project + feature

  for (const t of plan.tasks) {
    const { feature, project } = lineage(t, parents);
    if (projectIds && !(project && projectIds.has(project.id))) continue;
    if (featureIds && !(feature && featureIds.has(feature.id))) continue;

    const blocks = blocksByTask.get(t.id) ?? [];
    if ((from || to) && blocks.length === 0) continue;

    const pKey = project?.id ?? "";
    let p = projects.get(pKey);
    if (!p) {
      p = { id: project?.id, title: project?.title ?? NO_PROJECT, deadline: project?.deadline, features: [] };
      projects.set(pKey, p);
    }
    const fKey = `${pKey}/${feature?.id ?? ""}`;
    let f = featureRows.get(fKey);
    if (!f) {
      f = { id: feature?.id, title: feature?.title ?? NO_FEATURE, deadline: feature?.deadline, tasks: [] };
      featureRows.set(fKey, f);
      p.features.push(f);
    }

    f.tasks.push({
      id: t.id,
      title: t.title,
      priority: t.priority,
      status: meta.get(t.id)?.status ?? "todo",
      deadline: t.deadline,
      depends_on: meta.get(t.id)?.depends_on ?? [],
      estimate: meta.get(t.id)?.estimate,
      hours: t.hours,
      start: t.start,
      end: t.end,
      blocks,
      late_days: t.late_days,
      at_risk: t.late_days > 0,
      pulled_forward: t.pulled_forward,
    });
  }

  return [...projects.values()];
}

/** Default axis range: the whole plan plus today, unless the filters set the bounds. */
export function ganttRange(rows: GanttProject[], today: string, filters: Pick<GanttFilters, "from" | "to"> = {}) {
  let lo = today;
  let hi = today;
  for (const p of rows)
    for (const f of p.features)
      for (const t of f.tasks) {
        if (t.start.date < lo) lo = t.start.date;
        if (t.end.date > hi) hi = t.end.date;
      }
  const from = filters.from ?? lo;
  return { from, to: filters.to ?? (hi < from ? from : hi) };
}

/** Feature choices for the filter UI, narrowed to the selected projects (all when none). */
export function featureOptions(features: FeatureMeta[], selectedProjects: string[]): FeatureMeta[] {
  if (!selectedProjects.length) return features;
  return features.filter((f) => f.project && selectedProjects.includes(f.project));
}

type Query = Record<string, string | string[] | undefined>;
const many = (v: string | string[] | undefined) => (Array.isArray(v) ? v : v ? [v] : []).filter(Boolean);
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
const date = (v: string | string[] | undefined) => {
  const d = one(v);
  return d && DATE.test(d) ? d : undefined;
};

/** Filters, unit and view centre from the page's query (`?project=&feature=&from=&to=&unit=&at=`). */
export function parseGanttQuery(query: Query, features: FeatureMeta[] = []) {
  const projects = many(query.project);
  // A feature filter only makes sense inside the selected projects.
  const allowed = new Set(featureOptions(features, projects).map((f) => f.id));
  const selected = many(query.feature).filter((id) => !features.length || allowed.has(id));
  const unit = UNITS.find((u) => u === one(query.unit)) ?? ("day" satisfies Unit);
  const at = one(query.at)?.match(/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})$/);
  return {
    filters: { projects, features: selected, from: date(query.from), to: date(query.to) } satisfies GanttFilters,
    unit,
    at: at ? { date: at[1], time: at[2] } : undefined,
  };
}
