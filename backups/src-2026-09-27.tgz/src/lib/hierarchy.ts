import type { FeatureMeta, Priority, ProjectMeta, ProjectStatus } from "./types";

/**
 * Project → Feature → Task. A task belongs to a project through its feature;
 * priority and deadline are inherited downwards when a level doesn't set its own.
 */

export interface Lookup {
  features: Map<string, FeatureMeta>;
  projects: Map<string, ProjectMeta>;
}

export function lookup(features: FeatureMeta[] = [], projects: ProjectMeta[] = []): Lookup {
  return { features: new Map(features.map((f) => [f.id, f])), projects: new Map(projects.map((p) => [p.id, p])) };
}

export function lineage(task: { feature?: string }, { features, projects }: Lookup) {
  const feature = task.feature ? features.get(task.feature) : undefined;
  const project = feature?.project ? projects.get(feature.project) : undefined;
  return { feature, project };
}

export function inheritedPriority(...levels: (Priority | undefined)[]): Priority {
  return levels.find((p) => p !== undefined) ?? "P2";
}

export function earliestDate(...dates: (string | undefined)[]): string | undefined {
  return dates.filter((d): d is string => Boolean(d)).sort()[0];
}

const SCHEDULABLE_PROJECT: ProjectStatus[] = ["planned", "active"];

/** Why a project keeps its tasks off the schedule, if it does. */
export function projectHold(project?: ProjectMeta): string | undefined {
  if (!project || SCHEDULABLE_PROJECT.includes(project.status)) return undefined;
  return `project ${project.id} is ${project.status.replace("_", " ")}`;
}
