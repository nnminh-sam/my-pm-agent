import { z } from "zod";
import { pert } from "./estimation";
import { getRepository, type Repository } from "./repository";
import { idNumber, type TaskDraft } from "./repository/types";
import { todayIn } from "./time";
import {
  ApiKey,
  Feature,
  FeatureStatus,
  Priority,
  Project,
  ProjectStatus,
  Settings,
  SettingsPatch,
  Task,
  TaskStatus,
  User,
  dateStr,
} from "./types";

// ---------------------------------------------------------------------------
// Input shapes shared by the MCP tools and the web UI
// ---------------------------------------------------------------------------

export const PertInput = z
  .object({
    optimistic: z.number().nonnegative(),
    likely: z.number().nonnegative(),
    pessimistic: z.number().nonnegative(),
  })
  .describe("Three-point estimate in hours; stored as the PERT mean (o + 4m + p) / 6 plus the [o, p] range.");

export const NewTask = z.object({
  ref: z.string().optional().describe("Temporary key so other tasks in the same batch can depend on this one."),
  title: z.string().min(1),
  description: z.string().optional().describe("Markdown: context, acceptance criteria, notes."),
  feature: z.string().optional().describe("Feature id, e.g. F-2."),
  priority: Priority.optional().describe("P0 (critical) … P3 (low). Defaults to the feature's priority."),
  estimate: z.number().nonnegative().optional().describe("Hours. Prefer `pert` for anything non-trivial."),
  pert: PertInput.optional(),
  deadline: dateStr.optional(),
  not_before: dateStr.optional(),
  depends_on: z.array(z.string()).optional().describe("Existing task ids or `ref`s from this batch."),
  tags: z.array(z.string()).optional(),
  status: TaskStatus.optional(),
});
export type NewTask = z.infer<typeof NewTask>;

export const TaskPatch = z.object({
  title: z.string().min(1).optional(),
  status: TaskStatus.optional(),
  priority: Priority.nullable().optional().describe("null → inherit from the feature."),
  feature: z.string().nullable().optional(),
  estimate: z.number().nonnegative().optional(),
  pert: PertInput.optional(),
  spent: z.number().nonnegative().optional().describe("Total hours worked (overwrites). Use log_time to add."),
  deadline: dateStr.nullable().optional(),
  not_before: dateStr.nullable().optional(),
  depends_on: z.array(z.string()).optional(),
  tags: z.array(z.string()).optional(),
  order: z.number().nullable().optional(),
  description: z.string().optional().describe("Replaces the markdown body."),
  append_note: z.string().optional().describe("Appended to the body under a dated heading."),
});
export type TaskPatch = z.infer<typeof TaskPatch>;

export const NewFeature = z.object({
  title: z.string().min(1),
  project: z.string().optional().describe("Project id, e.g. PRJ-1."),
  description: z.string().optional().describe("Markdown spec: goal, scope, out of scope, acceptance criteria."),
  priority: Priority.optional().describe("Defaults to the project's priority."),
  deadline: dateStr.optional(),
  status: FeatureStatus.optional(),
});
export type NewFeature = z.infer<typeof NewFeature>;

export const FeaturePatch = z.object({
  title: z.string().min(1).optional(),
  project: z.string().nullable().optional().describe("Move to another project; null → no project."),
  description: z.string().optional(),
  priority: Priority.nullable().optional().describe("null → inherit from the project."),
  deadline: dateStr.nullable().optional(),
  status: FeatureStatus.optional(),
});
export type FeaturePatch = z.infer<typeof FeaturePatch>;

export const NewProject = z.object({
  title: z.string().min(1),
  description: z.string().optional().describe("Markdown: goal, success criteria, constraints, milestones."),
  priority: Priority.optional().describe("Default for its features and tasks (P2 if omitted)."),
  deadline: dateStr.optional().describe("Applies to every task in the project."),
  status: ProjectStatus.optional(),
});
export type NewProject = z.infer<typeof NewProject>;

export const ProjectPatch = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  priority: Priority.optional(),
  deadline: dateStr.nullable().optional(),
  status: ProjectStatus.optional().describe("on_hold / done / cancelled take the project's tasks off the schedule."),
});
export type ProjectPatch = z.infer<typeof ProjectPatch>;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

type Prefix = "T" | "F" | "PRJ" | "U" | "K";

export function normalizeId(id: string, prefix: Prefix) {
  const trimmed = id.trim().toUpperCase();
  if (/^\d+$/.test(trimmed)) return `${prefix}-${trimmed}`;
  return trimmed;
}

export class NotFoundError extends Error {}

function assertNoCycle(tasks: Map<string, { depends_on: string[] }>, start: string) {
  const seen = new Set<string>();
  const stack = [...(tasks.get(start)?.depends_on ?? [])];
  while (stack.length) {
    const id = stack.pop()!;
    if (id === start) throw new Error(`Dependency cycle: ${start} would depend on itself`);
    if (seen.has(id)) continue;
    seen.add(id);
    stack.push(...(tasks.get(id)?.depends_on ?? []));
  }
}

function withNote(body: string, heading: string, note: string) {
  return `${body.trim()}\n\n### ${heading}\n\n${note.trim()}`.trim();
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export async function getSettings(repo: Repository = getRepository()): Promise<Settings> {
  const data = { ...((await repo.readSettings()) ?? {}) };
  if (!data.timezone && process.env.PM_TIMEZONE) data.timezone = process.env.PM_TIMEZONE;
  return Settings.parse(data);
}

export async function updateSettings(patch: SettingsPatch): Promise<Settings> {
  const current = await getSettings();
  const defined = Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined));
  const next = Settings.parse({ ...current, ...defined });
  await getRepository().writeSettings(next);
  return next;
}

// ---------------------------------------------------------------------------
// Loading
// ---------------------------------------------------------------------------

export interface Workspace {
  settings: Settings;
  tasks: Task[];
  features: Feature[];
  projects: Project[];
  /** Records that couldn't be parsed; they're skipped rather than breaking everything. */
  problems: string[];
}

export async function loadWorkspace(repo: Repository = getRepository()): Promise<Workspace> {
  const [settings, { tasks, features, projects, problems }] = await Promise.all([getSettings(repo), repo.loadAll()]);
  for (const list of [tasks, features, projects]) list.sort((a, b) => idNumber(a.id) - idNumber(b.id));
  return { settings, tasks, features, projects, problems };
}

export async function getTask(id: string): Promise<Task> {
  const taskId = normalizeId(id, "T");
  const task = await getRepository().getTask(taskId);
  if (!task) throw new NotFoundError(`Task ${taskId} not found`);
  return task;
}

export async function getFeature(id: string): Promise<Feature> {
  const featureId = normalizeId(id, "F");
  const feature = await getRepository().getFeature(featureId);
  if (!feature) throw new NotFoundError(`Feature ${featureId} not found`);
  return feature;
}

export async function getProject(id: string): Promise<Project> {
  const projectId = normalizeId(id, "PRJ");
  const project = await getRepository().getProject(projectId);
  if (!project) throw new NotFoundError(`Project ${projectId} not found`);
  return project;
}

// ---------------------------------------------------------------------------
// Tasks
// ---------------------------------------------------------------------------

export async function createTasks(inputs: NewTask[]): Promise<Task[]> {
  const ws = await loadWorkspace();
  const today = todayIn(ws.settings.timezone);
  const featureIds = new Set(ws.features.map((f) => f.id));
  const existing = new Set(ws.tasks.map((t) => t.id));
  const refIndex = new Map<string, number>();
  for (const [index, input] of inputs.entries()) {
    if (!input.ref) continue;
    if (refIndex.has(input.ref)) throw new Error(`Duplicate ref "${input.ref}" in this batch`);
    refIndex.set(input.ref, index);
  }

  for (const input of inputs) {
    if (input.feature && !featureIds.has(normalizeId(input.feature, "F"))) {
      throw new NotFoundError(`Feature ${input.feature} not found (task "${input.title}")`);
    }
    for (const dep of input.depends_on ?? []) {
      if (!refIndex.has(dep) && !existing.has(normalizeId(dep, "T"))) {
        throw new NotFoundError(`"${input.title}" depends on ${dep}, which is neither an existing task nor a ref in this batch`);
      }
    }
    if (input.pert) pert(input.pert.optimistic, input.pert.likely, input.pert.pessimistic); // validate early
  }
  // Existing tasks can't depend on new ones, so only refs inside the batch can form a cycle.
  const refGraph = new Map(
    inputs.filter((t) => t.ref).map((t) => [t.ref!, { depends_on: (t.depends_on ?? []).filter((d) => refIndex.has(d)) }]),
  );
  for (const ref of refGraph.keys()) assertNoCycle(refGraph, ref);

  const drafts = inputs.map((input, index): TaskDraft => {
    // Existing ids and earlier refs keep their order; forward refs (to tasks listed later) go last.
    const deps: TaskDraft["depends_on"] = [];
    const later: TaskDraft["depends_on"] = [];
    for (const dep of input.depends_on ?? []) {
      const ref = refIndex.get(dep);
      if (ref === undefined) deps.push(normalizeId(dep, "T"));
      else (ref < index ? deps : later).push({ index: ref });
    }
    const estimate = input.pert
      ? pert(input.pert.optimistic, input.pert.likely, input.pert.pessimistic)
      : { estimate: input.estimate, estimate_range: undefined };
    return {
      title: input.title,
      status: input.status ?? "todo",
      priority: input.priority,
      feature: input.feature ? normalizeId(input.feature, "F") : undefined,
      estimate: estimate.estimate,
      estimate_range: estimate.estimate_range,
      spent: 0,
      deadline: input.deadline,
      not_before: input.not_before,
      depends_on: [...deps, ...later],
      tags: input.tags ?? [],
      created: today,
      body: input.description ?? "",
    };
  });
  return getRepository().insertTasks(drafts);
}

export async function updateTask(id: string, patch: TaskPatch): Promise<Task> {
  const task = await getTask(id);
  const settings = await getSettings();
  const today = todayIn(settings.timezone);
  const next: Task = { ...task };

  if (patch.title !== undefined) next.title = patch.title;
  if (patch.priority !== undefined) next.priority = patch.priority ?? undefined;
  if (patch.feature !== undefined) {
    next.feature = patch.feature ? normalizeId(patch.feature, "F") : undefined;
    if (next.feature) await getFeature(next.feature);
  }
  if (patch.pert) Object.assign(next, pert(patch.pert.optimistic, patch.pert.likely, patch.pert.pessimistic));
  else if (patch.estimate !== undefined) {
    next.estimate = patch.estimate;
    next.estimate_range = undefined;
  }
  if (patch.spent !== undefined) next.spent = patch.spent;
  if (patch.deadline !== undefined) next.deadline = patch.deadline ?? undefined;
  if (patch.not_before !== undefined) next.not_before = patch.not_before ?? undefined;
  if (patch.tags !== undefined) next.tags = patch.tags;
  if (patch.order !== undefined) next.order = patch.order ?? undefined;
  if (patch.description !== undefined) next.body = patch.description;
  if (patch.append_note) next.body = withNote(next.body, `Note · ${today}`, patch.append_note);
  if (patch.status !== undefined && patch.status !== task.status) {
    next.status = patch.status;
    next.completed = patch.status === "done" ? today : undefined;
  }
  if (patch.depends_on !== undefined) {
    const ws = await loadWorkspace();
    const ids = new Set(ws.tasks.map((t) => t.id));
    next.depends_on = patch.depends_on.map((d) => normalizeId(d, "T"));
    for (const dep of next.depends_on) if (!ids.has(dep)) throw new NotFoundError(`Task ${dep} not found`);
    const graph = new Map<string, { depends_on: string[] }>(ws.tasks.map((t) => [t.id, t]));
    graph.set(next.id, next);
    assertNoCycle(graph, next.id);
  }

  await getRepository().saveTasks([next]);
  return next;
}

export async function logTime(id: string, hours: number, note?: string, done?: boolean): Promise<Task> {
  const task = await getTask(id);
  const settings = await getSettings();
  const today = todayIn(settings.timezone);
  const next: Task = { ...task, spent: Math.round((task.spent + hours) * 100) / 100 };
  if (done) {
    next.status = "done";
    next.completed = today;
  } else if (task.status === "todo") {
    next.status = "in_progress";
  }
  const line = `- ${today}: ${hours}h${note ? ` — ${note.trim()}` : ""}`;
  next.body = /^## Log$/m.test(next.body) ? `${next.body.trim()}\n${line}` : `${next.body.trim()}\n\n## Log\n\n${line}`.trim();
  await getRepository().saveTasks([next]);
  return next;
}

/** Give tasks an explicit order (0, 1, 2…) — the tie-breaker within a priority level. */
export async function reorderTasks(ids: string[]): Promise<Task[]> {
  const tasks = await Promise.all(ids.map((id) => getTask(id)));
  const updated = tasks.map((task, index) => ({ ...task, order: index }));
  await getRepository().saveTasks(updated);
  return updated;
}

// ---------------------------------------------------------------------------
// Features
// ---------------------------------------------------------------------------

export async function createFeature(input: NewFeature): Promise<Feature> {
  const settings = await getSettings();
  const project = input.project ? (await getProject(input.project)).id : undefined;
  return getRepository().insertFeature({
    title: input.title,
    status: input.status ?? "planned",
    project,
    priority: input.priority,
    deadline: input.deadline,
    created: todayIn(settings.timezone),
    body: input.description ?? "",
  });
}

export async function updateFeature(id: string, patch: FeaturePatch): Promise<Feature> {
  const feature = await getFeature(id);
  const next: Feature = { ...feature };
  if (patch.title !== undefined) next.title = patch.title;
  if (patch.project !== undefined) next.project = patch.project ? (await getProject(patch.project)).id : undefined;
  if (patch.description !== undefined) next.body = patch.description;
  if (patch.priority !== undefined) next.priority = patch.priority ?? undefined;
  if (patch.deadline !== undefined) next.deadline = patch.deadline ?? undefined;
  if (patch.status !== undefined) next.status = patch.status;
  await getRepository().saveFeature(next);
  return next;
}

// ---------------------------------------------------------------------------
// Projects
// ---------------------------------------------------------------------------

export async function createProject(input: NewProject): Promise<Project> {
  const settings = await getSettings();
  return getRepository().insertProject({
    title: input.title,
    status: input.status ?? "active",
    priority: input.priority ?? "P2",
    deadline: input.deadline,
    created: todayIn(settings.timezone),
    body: input.description ?? "",
  });
}

export async function updateProject(id: string, patch: ProjectPatch): Promise<Project> {
  const project = await getProject(id);
  const next: Project = { ...project };
  if (patch.title !== undefined) next.title = patch.title;
  if (patch.description !== undefined) next.body = patch.description;
  if (patch.priority !== undefined) next.priority = patch.priority;
  if (patch.deadline !== undefined) next.deadline = patch.deadline ?? undefined;
  if (patch.status !== undefined) next.status = patch.status;
  await getRepository().saveProject(next);
  return next;
}

// ---------------------------------------------------------------------------
// Users (password hashing lives in src/lib/auth; never log password_hash)
// ---------------------------------------------------------------------------

/** Trimmed and lowercased: the form every email is stored and looked up in. */
export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** A simple `local@domain.tld` check (at most 254 chars, no spaces). Checks the email as given, so normalize first. */
export function isValidEmail(email: string): boolean {
  return email.length <= 254 && EMAIL.test(email);
}

export async function findUserByEmail(email: string): Promise<User | null> {
  return getRepository().findUserByEmail(normalizeEmail(email));
}

/** The user, or null when there's no such id (e.g. a session outliving its account). */
export async function getUser(id: string): Promise<User | null> {
  return getRepository().getUser(normalizeId(id, "U"));
}

export async function countUsers(): Promise<number> {
  return getRepository().countUsers();
}

/** Stores a new account; `password_hash` must already be hashed. Returns null when the email is taken. */
export async function createUser(input: { email: string; password_hash: string }): Promise<User | null> {
  const email = normalizeEmail(input.email);
  if (!isValidEmail(email)) throw new Error("Invalid email address");
  if (!input.password_hash) throw new Error("password_hash is required");
  const repository = getRepository();
  // Checked first so a duplicate doesn't use up an id; the backend still enforces uniqueness.
  if (await repository.findUserByEmail(email)) return null;
  const settings = await getSettings(repository);
  return repository.insertUser({ email, password_hash: input.password_hash, created: todayIn(settings.timezone) });
}

// ---------------------------------------------------------------------------
// API keys (generation, hashing and verification live in src/lib/auth/api-keys.ts;
// only hashes reach the repository, and neither raw keys nor hashes are ever logged)
// ---------------------------------------------------------------------------

const API_KEY_HASH = /^[0-9a-f]{64}$/;
const API_KEY_ID = /^K-\d+$/;

/** The key id in its `K-n` form, or null for anything else (so no lookup is made for junk ids). */
function apiKeyId(id: string): string | null {
  const keyId = normalizeId(id, "K");
  return API_KEY_ID.test(keyId) ? keyId : null;
}

/** Stores a new key by its hash (lowercase hex SHA-256, see hashApiKey); the raw key is never passed here. */
export async function createApiKey(input: { label?: string; hash: string; user_id?: string }): Promise<ApiKey> {
  if (!API_KEY_HASH.test(input.hash)) throw new Error("hash must be a lowercase hex SHA-256");
  const repository = getRepository();
  const settings = await getSettings(repository);
  const draft = { label: (input.label ?? "").trim(), hash: input.hash, created: todayIn(settings.timezone) };
  return repository.insertApiKey(input.user_id ? { ...draft, user_id: normalizeId(input.user_id, "U") } : draft);
}

/** Exact hash match, revoked keys included (verifyApiKey rejects those). */
export async function findApiKeyByHash(hash: string): Promise<ApiKey | null> {
  if (!API_KEY_HASH.test(hash)) return null;
  return getRepository().findApiKeyByHash(hash);
}

/** Every key, revoked ones included, by id number. */
export async function listApiKeys(): Promise<ApiKey[]> {
  return getRepository().listApiKeys();
}

/** The keys an account created in the web UI, revoked ones included, by id number. */
export async function listUserApiKeys(userId: string): Promise<ApiKey[]> {
  const owner = normalizeId(userId, "U");
  return (await listApiKeys()).filter((key) => key.user_id === owner);
}

/** The key, or null when there's no such id. */
export async function getApiKey(id: string): Promise<ApiKey | null> {
  const keyId = apiKeyId(id);
  return keyId ? getRepository().getApiKey(keyId) : null;
}

/** Sets `revoked_at` (soft delete). Idempotent: an already-revoked key comes back unchanged; null for an unknown id. */
export async function revokeApiKey(id: string, at: Date = new Date()): Promise<ApiKey | null> {
  const key = await getApiKey(id);
  if (!key || key.revoked_at) return key;
  const next: ApiKey = { ...key, revoked_at: at.toISOString() };
  await getRepository().saveApiKey(next);
  return next;
}

/**
 * Records a use of the key: only `last_used_at` is written, so it never undoes a concurrent revoke (the
 * returned key then carries `revoked_at`). Null for an unknown id.
 */
export async function touchApiKey(id: string, at: Date = new Date()): Promise<ApiKey | null> {
  const keyId = apiKeyId(id);
  return keyId ? getRepository().touchApiKey(keyId, at.toISOString()) : null;
}
