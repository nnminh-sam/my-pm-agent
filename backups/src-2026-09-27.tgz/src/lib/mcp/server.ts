import type { McpServer } from "@modelcontextprotocol/server";
import { z } from "zod";
import { estimationStats } from "../estimation";
import { featureSummary, projectSummary, renderSchedule, scheduleFor } from "../planning";
import {
  FeaturePatch,
  NewFeature,
  NewProject,
  NewTask,
  ProjectPatch,
  TaskPatch,
  createFeature,
  createProject,
  createTasks,
  getFeature,
  getProject,
  getTask,
  loadWorkspace,
  logTime,
  normalizeId,
  reorderTasks,
  updateFeature,
  updateProject,
  updateSettings,
  updateTask,
  type Workspace,
} from "../repo";
import type { ScheduleResult } from "../scheduler";
import { getRepository } from "../repository";
import { nowIn } from "../time";
import { SettingsPatch, TaskStatus, type Task } from "../types";
import { CHECKIN_PROMPT, REPLAN_PROMPT, breakdownPrompt, estimatePrompt, projectBreakdownPrompt } from "./prompts";

type ToolResult = { content: { type: "text"; text: string }[]; isError?: boolean };

const json = (data: unknown): ToolResult => ({ content: [{ type: "text", text: JSON.stringify(data, null, 2) }] });
const text = (value: string): ToolResult => ({ content: [{ type: "text", text: value }] });

async function run(fn: () => Promise<ToolResult>): Promise<ToolResult> {
  try {
    return await fn();
  } catch (err) {
    const message = err instanceof z.ZodError ? z.prettifyError(err) : (err as Error).message;
    return { isError: true, content: [{ type: "text", text: message }] };
  }
}

const READ = { readOnlyHint: true, destructiveHint: false, openWorldHint: false } as const;
const WRITE = { readOnlyHint: false, destructiveHint: false, openWorldHint: false } as const;
const noArgs = z.object({});

function taskRow(t: Task, plan?: ScheduleResult) {
  const slot = plan?.tasks.find((s) => s.id === t.id);
  return {
    id: t.id,
    title: t.title,
    status: t.status,
    priority: t.priority,
    feature: t.feature,
    estimate: t.estimate,
    estimate_range: t.estimate_range,
    spent: t.spent || undefined,
    deadline: t.deadline,
    not_before: t.not_before,
    depends_on: t.depends_on.length ? t.depends_on : undefined,
    tags: t.tags.length ? t.tags : undefined,
    order: t.order,
    scheduled: slot ? `${slot.start.date} ${slot.start.time} → ${slot.end.date} ${slot.end.time}` : undefined,
    late_days: slot?.late_days || undefined,
    not_scheduled: plan?.unscheduled.find((u) => u.id === t.id)?.reason,
  };
}

/** What changed for the plan as a whole — returned after every write so the agent sees the impact. */
function impact(ws: Workspace, ids: string[]) {
  const plan = scheduleFor(ws);
  return {
    plan,
    summary: {
      finish: plan.finish ? `${plan.finish.date} ${plan.finish.time}` : undefined,
      total_hours: plan.total_hours,
      at_risk: plan.at_risk,
      not_scheduled: plan.unscheduled.filter((u) => ids.includes(u.id)),
    },
  };
}

export function registerPmServer(server: McpServer) {
  // ---------------------------------------------------------------- overview
  server.registerTool(
    "get_overview",
    {
      title: "Overview",
      description:
        "Start here. Today's date and plan, active projects and features with progress and projected finish, deadline risks, settings and data problems.",
      inputSchema: noArgs,
      annotations: READ,
    },
    async () =>
      run(async () => {
        const ws = await loadWorkspace();
        const plan = scheduleFor(ws);
        const now = nowIn(ws.settings.timezone);
        const titles = new Map(ws.tasks.map((t) => [t.id, t.title]));
        const counts: Record<string, number> = {};
        for (const t of ws.tasks) counts[t.status] = (counts[t.status] ?? 0) + 1;
        return json({
          now: `${now.date} ${String(Math.floor(now.minutes / 60)).padStart(2, "0")}:${String(now.minutes % 60).padStart(2, "0")}`,
          timezone: ws.settings.timezone,
          storage: getRepository().kind,
          task_counts: counts,
          projects: ws.projects
            .filter((p) => p.status !== "done" && p.status !== "cancelled")
            .map((p) => projectSummary(p, ws, plan)),
          features: ws.features
            .filter((f) => f.status !== "done" && f.status !== "cancelled")
            .map((f) => featureSummary(f, ws, plan)),
          today: (plan.days.find((d) => d.date === now.date)?.blocks ?? []).map(
            (b) => `${b.start}–${b.end} ${b.task} ${titles.get(b.task)}`,
          ),
          finish: plan.finish,
          remaining_hours: plan.total_hours,
          at_risk: plan.at_risk,
          not_scheduled: plan.unscheduled,
          warnings: plan.warnings,
          settings: ws.settings,
          problems: ws.problems.length ? ws.problems : undefined,
        });
      }),
  );

  // ------------------------------------------------------------------- tasks
  server.registerTool(
    "list_tasks",
    {
      title: "List tasks",
      description: "List tasks with their scheduled slot. Done and cancelled tasks are hidden unless include_closed is true.",
      inputSchema: z.object({
        status: z.array(TaskStatus).optional(),
        project: z.string().optional().describe("Project id: tasks of all its features."),
        feature: z.string().optional().describe("Feature id; use 'none' for tasks without a feature."),
        tag: z.string().optional(),
        unestimated: z.boolean().optional().describe("Only tasks without an estimate."),
        include_closed: z.boolean().optional(),
      }),
      annotations: READ,
    },
    async (args) =>
      run(async () => {
        const ws = await loadWorkspace();
        const plan = scheduleFor(ws);
        const feature = args.feature && args.feature !== "none" ? normalizeId(args.feature, "F") : args.feature;
        const project = args.project ? normalizeId(args.project, "PRJ") : undefined;
        const inProject = new Set(ws.features.filter((f) => f.project === project).map((f) => f.id));
        const tasks = ws.tasks.filter(
          (t) =>
            (args.status
              ? args.status.includes(t.status)
              : args.include_closed || (t.status !== "done" && t.status !== "cancelled")) &&
            (!feature || (feature === "none" ? !t.feature : t.feature === feature)) &&
            (!project || (t.feature !== undefined && inProject.has(t.feature))) &&
            (!args.tag || t.tags.includes(args.tag)) &&
            (!args.unestimated || t.estimate === undefined),
        );
        return json(tasks.map((t) => taskRow(t, plan)));
      }),
  );

  server.registerTool(
    "get_task",
    {
      title: "Get task",
      description: "A task's full details, including its markdown description, log and scheduled slot.",
      inputSchema: z.object({ id: z.string().describe("e.g. T-12") }),
      annotations: READ,
    },
    async ({ id }) =>
      run(async () => {
        const [task, ws] = await Promise.all([getTask(id), loadWorkspace()]);
        return json({ ...taskRow(task, scheduleFor(ws)), created: task.created, completed: task.completed, description: task.body });
      }),
  );

  server.registerTool(
    "create_tasks",
    {
      title: "Create tasks",
      description:
        "Create one or more tasks in one call (preferred for breakdowns). Give each task a `ref` so others in the batch can depend on it. Returns the new ids and the effect on the schedule.",
      inputSchema: z.object({ tasks: z.array(NewTask).min(1).max(100) }),
      annotations: WRITE,
    },
    async ({ tasks }) =>
      run(async () => {
        const created = await createTasks(tasks);
        const ws = await loadWorkspace();
        const { plan, summary } = impact(
          ws,
          created.map((t) => t.id),
        );
        return json({ created: created.map((t) => taskRow(t, plan)), schedule: summary });
      }),
  );

  server.registerTool(
    "update_task",
    {
      title: "Update task",
      description:
        "Change any task field — status, priority, estimate (or pert), deadline, not_before, depends_on, order, tags, description — or append a note. Nullable fields accept null to clear them. Returns the task's new slot and the effect on the schedule.",
      inputSchema: TaskPatch.extend({ id: z.string() }),
      annotations: { ...WRITE, idempotentHint: true },
    },
    async ({ id, ...patch }) =>
      run(async () => {
        const task = await updateTask(id, patch);
        const ws = await loadWorkspace();
        const { plan, summary } = impact(ws, [task.id]);
        return json({ task: taskRow(task, plan), schedule: summary });
      }),
  );

  server.registerTool(
    "log_time",
    {
      title: "Log time",
      description:
        "Add hours worked on a task (moves it to in_progress). Set done=true to complete it. Logged time drives estimate calibration.",
      inputSchema: z.object({
        id: z.string(),
        hours: z.number().positive(),
        note: z.string().optional(),
        done: z.boolean().optional(),
      }),
      annotations: WRITE,
    },
    async ({ id, hours, note, done }) =>
      run(async () => {
        const task = await logTime(id, hours, note, done);
        const ws = await loadWorkspace();
        const { plan, summary } = impact(ws, [task.id]);
        return json({ task: taskRow(task, plan), schedule: summary });
      }),
  );

  server.registerTool(
    "reorder_tasks",
    {
      title: "Reorder tasks",
      description:
        "Set the manual order of tasks (first = do first). Order breaks ties within the same priority; to move a task ahead of higher-priority work, change its priority or add a dependency instead.",
      inputSchema: z.object({ ids: z.array(z.string()).min(1) }),
      annotations: { ...WRITE, idempotentHint: true },
    },
    async ({ ids }) =>
      run(async () => {
        const tasks = await reorderTasks(ids);
        const ws = await loadWorkspace();
        const { plan, summary } = impact(
          ws,
          tasks.map((t) => t.id),
        );
        return json({ tasks: tasks.map((t) => taskRow(t, plan)), schedule: summary });
      }),
  );

  // ---------------------------------------------------------------- features
  server.registerTool(
    "list_features",
    {
      title: "List features",
      description: "Features with task counts, estimated/remaining hours (± σ), progress and projected finish.",
      inputSchema: z.object({
        project: z.string().optional().describe("Project id; use 'none' for features without a project."),
      }),
      annotations: READ,
    },
    async (args) =>
      run(async () => {
        const ws = await loadWorkspace();
        const plan = scheduleFor(ws);
        const project = args.project && args.project !== "none" ? normalizeId(args.project, "PRJ") : args.project;
        return json(
          ws.features
            .filter((f) => !project || (project === "none" ? !f.project : f.project === project))
            .map((f) => featureSummary(f, ws, plan)),
        );
      }),
  );

  server.registerTool(
    "get_feature",
    {
      title: "Get feature",
      description: "A feature's spec, estimate rollup, projected finish and all of its tasks.",
      inputSchema: z.object({ id: z.string().describe("e.g. F-2") }),
      annotations: READ,
    },
    async ({ id }) =>
      run(async () => {
        const [feature, ws] = await Promise.all([getFeature(id), loadWorkspace()]);
        const plan = scheduleFor(ws);
        return json({
          ...featureSummary(feature, ws, plan),
          spec: feature.body,
          tasks: ws.tasks.filter((t) => t.feature === feature.id).map((t) => taskRow(t, plan)),
        });
      }),
  );

  server.registerTool(
    "create_feature",
    {
      title: "Create feature",
      description:
        "Create a feature (usually inside a project) with a markdown spec. Break it down afterwards with the breakdown_feature prompt.",
      inputSchema: NewFeature,
      annotations: WRITE,
    },
    async (input) => run(async () => json(await createFeature(input))),
  );

  server.registerTool(
    "update_feature",
    {
      title: "Update feature",
      description:
        "Change a feature's title, spec, project, priority, deadline or status. Tasks inherit its priority and deadline; it inherits from its project.",
      inputSchema: FeaturePatch.extend({ id: z.string() }),
      annotations: { ...WRITE, idempotentHint: true },
    },
    async ({ id, ...patch }) => run(async () => json(await updateFeature(id, patch))),
  );

  // ---------------------------------------------------------------- projects
  server.registerTool(
    "list_projects",
    {
      title: "List projects",
      description: "Projects with feature/task counts, estimated/remaining hours, progress and projected finish vs deadline.",
      inputSchema: z.object({ include_closed: z.boolean().optional().describe("Include done and cancelled projects.") }),
      annotations: READ,
    },
    async ({ include_closed }) =>
      run(async () => {
        const ws = await loadWorkspace();
        const plan = scheduleFor(ws);
        return json(
          ws.projects
            .filter((p) => include_closed || (p.status !== "done" && p.status !== "cancelled"))
            .map((p) => projectSummary(p, ws, plan)),
        );
      }),
  );

  server.registerTool(
    "get_project",
    {
      title: "Get project",
      description: "A project's description, rollup, projected finish and a summary of each of its features.",
      inputSchema: z.object({ id: z.string().describe("e.g. PRJ-1") }),
      annotations: READ,
    },
    async ({ id }) =>
      run(async () => {
        const [project, ws] = await Promise.all([getProject(id), loadWorkspace()]);
        const plan = scheduleFor(ws);
        return json({
          ...projectSummary(project, ws, plan),
          description: project.body,
          feature_list: ws.features.filter((f) => f.project === project.id).map((f) => featureSummary(f, ws, plan)),
        });
      }),
  );

  server.registerTool(
    "create_project",
    {
      title: "Create project",
      description:
        "Create a project: the top level that groups features. Its priority and deadline are inherited by its features and tasks. Plan its features afterwards with the breakdown_project prompt.",
      inputSchema: NewProject,
      annotations: WRITE,
    },
    async (input) => run(async () => json(await createProject(input))),
  );

  server.registerTool(
    "update_project",
    {
      title: "Update project",
      description:
        "Change a project's title, description, priority, deadline or status. Setting status to on_hold, done or cancelled takes all its tasks off the schedule.",
      inputSchema: ProjectPatch.extend({ id: z.string() }),
      annotations: { ...WRITE, idempotentHint: true },
    },
    async ({ id, ...patch }) =>
      run(async () => {
        const project = await updateProject(id, patch);
        const ws = await loadWorkspace();
        const plan = scheduleFor(ws);
        return json({
          project: projectSummary(project, ws, plan),
          schedule: { finish: plan.finish, total_hours: plan.total_hours, at_risk: plan.at_risk },
        });
      }),
  );

  // ---------------------------------------------------------------- schedule
  server.registerTool(
    "get_schedule",
    {
      title: "Get schedule",
      description:
        "Compute the plan from now: day-by-day time blocks, projected finish, deadline risks, unscheduled tasks (with reasons) and warnings (over-estimate, too large).",
      inputSchema: z.object({
        days: z.number().int().positive().max(90).optional().describe("Working days to show (default 10)."),
        format: z.enum(["text", "json"]).optional().describe("text (default) is a readable plan; json has every field."),
      }),
      annotations: READ,
    },
    async ({ days = 10, format = "text" }) =>
      run(async () => {
        const ws = await loadWorkspace();
        const plan = scheduleFor(ws);
        if (format === "json") return json({ ...plan, days: plan.days.slice(0, days) });
        return text(renderSchedule(plan, new Map(ws.tasks.map((t) => [t.id, t.title])), days));
      }),
  );

  server.registerTool(
    "get_estimation_stats",
    {
      title: "Estimation stats",
      description:
        "How accurate past estimates were (actual ÷ estimate), overall and per tag, plus recent completed tasks as reference points. Read before estimating.",
      inputSchema: noArgs,
      annotations: READ,
    },
    async () =>
      run(async () => {
        const ws = await loadWorkspace();
        return json({ current_buffer: ws.settings.buffer, ...estimationStats(ws.tasks) });
      }),
  );

  server.registerTool(
    "update_settings",
    {
      title: "Update settings",
      description:
        "Change timezone, working hours per weekday (e.g. mon: [\"09:00-12:00\",\"13:00-17:00\"]), days_off, per-date overrides, estimate buffer, min_block_hours, max_task_hours or horizon_days. Only the given fields change.",
      inputSchema: SettingsPatch,
      annotations: { ...WRITE, idempotentHint: true },
    },
    async (patch) => run(async () => json(await updateSettings(patch))),
  );

  // ----------------------------------------------------------------- prompts
  server.registerPrompt(
    "breakdown_project",
    {
      title: "Plan a project",
      description: "Turn a project's goal into features with specs, then break each feature into tasks.",
      argsSchema: z.object({ project_id: z.string().describe("e.g. PRJ-1") }),
    },
    async ({ project_id }) => ({
      messages: [{ role: "user", content: { type: "text", text: projectBreakdownPrompt(normalizeId(project_id, "PRJ")) } }],
    }),
  );

  server.registerPrompt(
    "breakdown_feature",
    {
      title: "Break down a feature",
      description: "Turn a feature spec into small, estimated, dependency-linked tasks.",
      argsSchema: z.object({ feature_id: z.string().describe("e.g. F-2") }),
    },
    async ({ feature_id }) => {
      const ws = await loadWorkspace();
      return {
        messages: [
          {
            role: "user",
            content: { type: "text", text: breakdownPrompt(normalizeId(feature_id, "F"), ws.settings.max_task_hours) },
          },
        ],
      };
    },
  );

  server.registerPrompt(
    "estimate_tasks",
    {
      title: "Estimate tasks",
      description: "Three-point estimates for unestimated tasks, calibrated against your history.",
      argsSchema: z.object({ feature_id: z.string().optional().describe("Limit to one feature.") }),
    },
    async ({ feature_id }) => {
      const ws = await loadWorkspace();
      const scope = feature_id
        ? `the open tasks of feature ${normalizeId(feature_id, "F")} that have no estimate`
        : "all open tasks that have no estimate";
      return {
        messages: [{ role: "user", content: { type: "text", text: estimatePrompt(scope, ws.settings.max_task_hours) } }],
      };
    },
  );

  server.registerPrompt(
    "replan",
    { title: "Replan", description: "Diagnose the schedule and propose a rearrangement.", argsSchema: noArgs },
    () => ({ messages: [{ role: "user", content: { type: "text", text: REPLAN_PROMPT } }] }),
  );

  server.registerPrompt(
    "daily_checkin",
    { title: "Daily check-in", description: "Log yesterday's work and show today's plan.", argsSchema: noArgs },
    () => ({ messages: [{ role: "user", content: { type: "text", text: CHECKIN_PROMPT } }] }),
  );
}
