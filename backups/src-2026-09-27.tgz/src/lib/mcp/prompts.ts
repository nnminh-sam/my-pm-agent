export const SERVER_INSTRUCTIONS = `Personal project-management system for one person.

Data model — Project → Feature → Task (markdown files with YAML frontmatter):
- Projects (PRJ-n): a goal/description, priority P0–P3, optional deadline, status planned|active|on_hold|done|cancelled. Tasks of on_hold/done/cancelled projects are not scheduled.
- Features (F-n): belong to a project; a spec in markdown, priority (inherits the project's), optional deadline.
- Tasks (T-n): belong to a feature; estimate in hours (optionally a three-point range), priority (inherits feature → project), deadline (the earliest of task/feature/project applies), depends_on, not_before, tags, logged time (spent), status todo|in_progress|blocked|done|cancelled.
- Settings: timezone, working hours per weekday, days off, estimate buffer.

A deterministic scheduler lays open tasks onto the working hours. Never work out a schedule yourself — call get_schedule. It respects dependencies, priority, deadlines (pulling late tasks forward when that helps) and marks deadline risks.

Workflows:
- New project: create_project with a goal, then follow the breakdown_project prompt to propose features (create_feature with project set), then break each feature down.
- New feature: create_feature with a spec (and its project), then follow the breakdown_feature prompt — tasks of at most max_task_hours, three-point estimates via \`pert\`, dependencies via \`ref\`, all in one create_tasks call.
- Estimating: read get_estimation_stats first and calibrate against the actual/estimate ratio of similar (same-tag) work.
- Rearranging: change priority, order (reorder_tasks), depends_on, not_before, deadline or the estimate with update_task. The schedule recomputes on every read, so call get_schedule afterwards to show the effect.
- Progress: log_time as work happens (this feeds estimate calibration). log_time with done=true completes a task.

Start with get_overview. Confirm with the user before bulk-creating, cancelling or re-prioritising several tasks.`;

export function projectBreakdownPrompt(projectId: string) {
  return `Act as my project manager and plan project ${projectId} as a set of features.

1. Call get_project("${projectId}") for its goal and any existing features, and list_projects to see what else competes for my time.
2. If the goal leaves scope unclear, list your assumptions — or ask me up to 3 questions — before drafting.
3. Propose the features:
   - Each feature is a user-visible capability or a coherent technical milestone that can ship on its own — typically 1–5 days of work.
   - For each: title, a short markdown spec (goal, scope, out of scope, acceptance criteria as a checklist), priority relative to the others (omit it to inherit the project's), and a rough size (S ≤ 1 day, M 2–3 days, L 4–5 days; split anything bigger).
   - Order them so foundations come first; note which features depend on which.
   - Call out what you are deliberately leaving out.
4. Show me the list as a table (title, size, priority, depends on) and wait for my OK.
5. Once I confirm, create each feature with create_feature (project: "${projectId}"). Then offer to break them down one by one with the breakdown_feature steps, starting with the first in order.`;
}

export function breakdownPrompt(featureId: string, maxTaskHours: number) {
  return `Act as my project manager and break feature ${featureId} down into schedulable tasks.

1. Call get_feature("${featureId}") for the spec and any existing tasks, and get_estimation_stats to see how my past estimates compared with actual time.
2. If the spec leaves scope unclear, list your assumptions — or ask me up to 3 questions — before drafting.
3. Draft the breakdown:
   - Each task is a concrete, verifiable outcome ("Add POST /login with input validation"), not an activity ("work on backend").
   - Each task is 0.5–${maxTaskHours}h of focused work; split anything bigger.
   - Include the work that usually gets forgotten: spikes for unknowns, tests, review fixes, docs, deploy and verification.
   - Give every task a three-point estimate (optimistic / likely / pessimistic hours). Express uncertainty with a wider range, not a padded "likely". Adjust with the calibration ratio for similar tags.
   - Use depends_on only for real ordering constraints (use \`ref\`s inside the batch).
   - Tag the kind of work (frontend, backend, infra, research, testing, …) — tags drive estimate calibration.
   - Description: 1–3 lines of context, then acceptance criteria as a checklist.
4. Show me the breakdown as a table (ref, title, o/m/p, expected, depends on) with the total expected hours ± σ, and wait for my OK.
5. Once I confirm, create everything in a single create_tasks call, then call get_schedule and tell me when the feature will be done and whether anything is at risk.`;
}

export function estimatePrompt(scope: string, maxTaskHours: number) {
  return `Estimate ${scope}.

1. Call list_tasks to find the open tasks without an estimate (or the ones I point out), then get_estimation_stats.
2. For each task, read get_task for details and give an optimistic / likely / pessimistic estimate in hours with a one-line rationale. Cite comparable completed tasks from the stats when you can, and apply the calibration ratio for similar tags.
3. Flag any task whose likely estimate exceeds ${maxTaskHours}h and propose how to split it.
4. Show a table and wait for my OK. Then save each estimate with update_task using \`pert\`.
5. Call get_schedule and summarise how the finish date and deadline risks changed.`;
}

export const REPLAN_PROMPT = `Review my schedule and help me rearrange it.

1. Call get_overview and get_schedule.
2. Diagnose: deadlines at risk, tasks that have run over their estimate, blocked or unestimated tasks, tasks too large to schedule well, and whether the order matches what matters most.
3. Propose concrete changes, each with its expected effect: re-prioritise (update_task priority, or reorder_tasks within a priority), re-estimate remaining work, add or remove dependencies, defer with not_before, move a deadline, split a task, or cut scope (status cancelled).
4. Wait for my OK, apply the changes, then show the new finish date and any remaining risks.`;

export const CHECKIN_PROMPT = `Run my daily check-in.

1. Call get_schedule with days=2.
2. Ask what I worked on since the last check-in (hours per task), and whether anything is done or blocked.
3. Record it with log_time (done=true for finished tasks) and update_task (status blocked, plus a note on why).
4. Show today's plan with times and call out anything at risk.`;
