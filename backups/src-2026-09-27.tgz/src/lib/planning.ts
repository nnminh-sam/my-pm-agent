import { rollup } from "./estimation";
import { earliestDate, inheritedPriority } from "./hierarchy";
import { schedule, type ScheduleResult } from "./scheduler";
import { fmtDay, fmtHours, nowIn } from "./time";
import type { Feature, Project, Task } from "./types";
import type { Workspace } from "./repo";

export function scheduleFor(ws: Workspace, at?: Date): ScheduleResult {
  return schedule({
    tasks: ws.tasks,
    features: ws.features,
    projects: ws.projects,
    settings: ws.settings,
    now: nowIn(ws.settings.timezone, at),
  });
}

/** Rollup + schedule outlook for any group of tasks. */
function outlook(tasks: Task[], plan: ScheduleResult, deadline?: string) {
  const ids = new Set(tasks.map((t) => t.id));
  const projected = plan.tasks
    .filter((t) => ids.has(t.id))
    .reduce<string | undefined>((max, t) => (!max || t.end.date > max ? t.end.date : max), undefined);
  const unscheduled = plan.unscheduled.filter((u) => ids.has(u.id));
  return {
    ...rollup(tasks),
    projected_finish: projected,
    on_track: deadline && projected ? projected <= deadline : undefined,
    unscheduled: unscheduled.length,
  };
}

/** The feature's own values, or what it inherits from its project. */
export function featureEffective(feature: Feature, ws: Pick<Workspace, "projects">) {
  const project = feature.project ? ws.projects.find((p) => p.id === feature.project) : undefined;
  return {
    project,
    priority: inheritedPriority(feature.priority, project?.priority),
    deadline: earliestDate(feature.deadline, project?.deadline),
  };
}

export function featureSummary(feature: Feature, ws: Workspace, plan: ScheduleResult) {
  const { project, priority, deadline } = featureEffective(feature, ws);
  return {
    id: feature.id,
    title: feature.title,
    project: project?.id,
    status: feature.status,
    priority,
    deadline,
    ...outlook(
      ws.tasks.filter((t) => t.feature === feature.id),
      plan,
      deadline,
    ),
  };
}

export function projectSummary(project: Project, ws: Workspace, plan: ScheduleResult) {
  const features = ws.features.filter((f) => f.project === project.id);
  const featureIds = new Set(features.map((f) => f.id));
  const featureCounts: Record<string, number> = {};
  for (const f of features) featureCounts[f.status] = (featureCounts[f.status] ?? 0) + 1;
  return {
    id: project.id,
    title: project.title,
    status: project.status,
    priority: project.priority,
    deadline: project.deadline,
    features: features.length,
    features_by_status: featureCounts,
    ...outlook(
      ws.tasks.filter((t) => t.feature && featureIds.has(t.feature)),
      plan,
      project.deadline,
    ),
  };
}

/** Human/LLM-friendly markdown rendering of a schedule. */
export function renderSchedule(plan: ScheduleResult, titles: Map<string, string>, maxDays = 10): string {
  const lines: string[] = [];
  lines.push(`Schedule from ${plan.from.date} ${plan.from.time} — ${fmtHours(plan.total_hours)} of planned work` +
    (plan.finish ? `, all done by ${fmtDay(plan.finish.date)} ${plan.finish.time}` : ""));
  if (plan.at_risk.length) {
    lines.push("", "## At risk");
    for (const r of plan.at_risk) lines.push(`- ${r.id} ${r.title}: due ${r.deadline}, finishes ${r.end} (${r.late_days}d late)`);
  }
  if (plan.warnings.length) {
    lines.push("", "## Warnings");
    for (const w of plan.warnings) lines.push(`- ${w}`);
  }
  lines.push("", "## Plan");
  for (const day of plan.days.slice(0, maxDays)) {
    lines.push(`### ${fmtDay(day.date)} (${day.date}) — ${fmtHours(day.planned_hours)} / ${fmtHours(day.capacity_hours)}`);
    for (const b of day.blocks) lines.push(`- ${b.start}–${b.end} ${b.task} ${titles.get(b.task) ?? ""} (${fmtHours(b.hours)})`);
  }
  if (plan.days.length > maxDays) lines.push(`… ${plan.days.length - maxDays} more working days`);
  if (plan.unscheduled.length) {
    lines.push("", "## Not scheduled");
    for (const u of plan.unscheduled) lines.push(`- ${u.id} ${u.title}: ${u.reason}`);
  }
  return lines.join("\n");
}
