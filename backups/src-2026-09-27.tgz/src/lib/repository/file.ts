import YAML from "yaml";
import { z } from "zod";
import { parseMarkdown, toMarkdown } from "../markdown";
import type { FileStore } from "../store/types";
import {
  ApiKeyMeta,
  FeatureMeta,
  ProjectMeta,
  TaskMeta,
  UserMeta,
  type ApiKey,
  type Feature,
  type Project,
  type Task,
  type User,
} from "../types";
import { idNumber, resolveDeps, type Records, type Repository, type TaskDraft } from "./types";

const SETTINGS_FILE = "settings.yaml";

/** `users/` holds accounts and `api_keys/` agent keys; they're never part of loadAll (and so never exported). */
type Dir = "tasks" | "features" | "projects" | "users" | "api_keys";
type Entity = Task | Feature | Project | User | ApiKey;

const META = { tasks: TaskMeta, features: FeatureMeta, projects: ProjectMeta, users: UserMeta, api_keys: ApiKeyMeta };
const PREFIX = { tasks: "T", features: "F", projects: "PRJ", users: "U", api_keys: "K" };
/** Records with no markdown body. */
const FRONTMATTER_ONLY = new Set<Dir>(["users", "api_keys"]);

async function mapLimit<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let next = 0;
  await Promise.all(
    Array.from({ length: Math.min(limit, items.length) }, async () => {
      while (next < items.length) {
        const i = next++;
        results[i] = await fn(items[i]);
      }
    }),
  );
  return results;
}

/** Frontmatter in the zod schema's key order, then the body. */
function serialize(dir: Dir, entity: Entity) {
  const { body, ...meta } = entity as Entity & Record<string, unknown>;
  const keys = Object.keys(META[dir].shape).filter((k) => k in meta);
  return toMarkdown(Object.fromEntries(keys.map((k) => [k, meta[k]])), (body as string | undefined) ?? "");
}

function parse<T extends Entity>(dir: Dir, text: string): T {
  const { data, body } = parseMarkdown(text);
  const meta = META[dir].parse(data);
  return (FRONTMATTER_ONLY.has(dir) ? meta : { ...meta, body }) as T;
}

/** Markdown files with YAML frontmatter on a FileStore. */
export class FileRepository implements Repository {
  readonly kind: "fs";

  constructor(private readonly store: FileStore) {
    this.kind = store.kind;
  }

  async readSettings() {
    const raw = await this.store.read(SETTINGS_FILE);
    return raw ? ((YAML.parse(raw) as Record<string, unknown> | null) ?? {}) : null;
  }

  async writeSettings(data: Record<string, unknown>) {
    await this.store.write(SETTINGS_FILE, YAML.stringify(data, { lineWidth: 0 }));
  }

  private async loadDir<T extends Entity>(dir: Dir, problems: string[]) {
    const paths = (await this.store.list(dir)).filter((p) => p.endsWith(".md"));
    const items = await mapLimit(paths, 16, async (p) => {
      const text = await this.store.read(p);
      if (text === null) return undefined;
      try {
        return parse<T>(dir, text);
      } catch (err) {
        problems.push(`${p}: ${err instanceof z.ZodError ? z.prettifyError(err) : (err as Error).message}`);
        return undefined;
      }
    });
    return items.filter((x): x is T => x !== undefined);
  }

  async loadAll(): Promise<Records> {
    const problems: string[] = [];
    const [tasks, features, projects] = await Promise.all([
      this.loadDir<Task>("tasks", problems),
      this.loadDir<Feature>("features", problems),
      this.loadDir<Project>("projects", problems),
    ]);
    return { tasks, features, projects, problems };
  }

  private async get<T extends Entity>(dir: Dir, id: string) {
    const text = await this.store.read(`${dir}/${id}.md`);
    return text === null ? null : parse<T>(dir, text);
  }

  getTask(id: string) {
    return this.get<Task>("tasks", id);
  }

  getFeature(id: string) {
    return this.get<Feature>("features", id);
  }

  getProject(id: string) {
    return this.get<Project>("projects", id);
  }

  private async nextNumber(dir: Dir) {
    const paths = await this.store.list(dir);
    return paths.reduce((max, p) => Math.max(max, idNumber(p.split("/").pop()!.replace(/\.md$/, ""))), 0) + 1;
  }

  /** Create a file with the next free id; retries if another request grabbed the same id. */
  private async createWithNextId(dir: Dir, build: (id: string) => Entity) {
    let n = await this.nextNumber(dir);
    for (let attempt = 0; attempt < 20; attempt++, n++) {
      const entity = build(`${PREFIX[dir]}-${n}`);
      if (await this.store.create(`${dir}/${entity.id}.md`, serialize(dir, entity))) return entity;
    }
    throw new Error(`Could not allocate a new ${PREFIX[dir]} id`);
  }

  async insertTasks(drafts: TaskDraft[]) {
    // Files are created one by one; forward refs are filled in by a second write once their ids exist.
    const ids: string[] = [];
    const tasks: Task[] = [];
    for (const [index, draft] of drafts.entries()) {
      const known = draft.depends_on.filter((d) => typeof d === "string" || d.index < index);
      const task = (await this.createWithNextId("tasks", (id) => ({
        id,
        ...draft,
        depends_on: resolveDeps(known, ids),
      }))) as Task;
      ids.push(task.id);
      tasks.push(task);
    }
    for (const [index, draft] of drafts.entries()) {
      if (draft.depends_on.some((d) => typeof d !== "string" && d.index >= index)) {
        tasks[index].depends_on = resolveDeps(draft.depends_on, ids);
        await this.store.write(`tasks/${tasks[index].id}.md`, serialize("tasks", tasks[index]));
      }
    }
    return tasks;
  }

  async insertFeature(draft: Omit<Feature, "id">) {
    return (await this.createWithNextId("features", (id) => ({ id, ...draft }))) as Feature;
  }

  async insertProject(draft: Omit<Project, "id">) {
    return (await this.createWithNextId("projects", (id) => ({ id, ...draft }))) as Project;
  }

  async saveTasks(tasks: Task[]) {
    for (const task of tasks) await this.store.write(`tasks/${task.id}.md`, serialize("tasks", task));
  }

  async saveFeature(feature: Feature) {
    await this.store.write(`features/${feature.id}.md`, serialize("features", feature));
  }

  async saveProject(project: Project) {
    await this.store.write(`projects/${project.id}.md`, serialize("projects", project));
  }

  getUser(id: string) {
    return this.get<User>("users", id);
  }

  /** Scans `users/`: fine for the handful of accounts a single-user app has. Unparseable files are skipped. */
  async findUserByEmail(email: string) {
    const users = await this.loadDir<User>("users", []);
    return users.find((u) => u.email === email) ?? null;
  }

  async countUsers() {
    return (await this.store.list("users")).filter((p) => p.endsWith(".md")).length;
  }

  /** The email check and the create aren't atomic; acceptable for a single-user app's sign-up. */
  async insertUser(draft: Omit<User, "id">) {
    if (await this.findUserByEmail(draft.email)) return null;
    return (await this.createWithNextId("users", (id) => ({ id, ...draft }))) as User;
  }

  async insertApiKey(draft: Omit<ApiKey, "id">) {
    return (await this.createWithNextId("api_keys", (id) => ({ id, ...draft }))) as ApiKey;
  }

  /** Scans `api_keys/`: a single-user app has a handful of keys. Unparseable files are skipped. */
  async findApiKeyByHash(hash: string) {
    const keys = await this.loadDir<ApiKey>("api_keys", []);
    return keys.find((k) => k.hash === hash) ?? null;
  }

  /** Unparseable files are skipped. */
  async listApiKeys() {
    const keys = await this.loadDir<ApiKey>("api_keys", []);
    return keys.sort((a, b) => idNumber(a.id) - idNumber(b.id));
  }

  getApiKey(id: string) {
    return this.get<ApiKey>("api_keys", id);
  }

  async saveApiKey(key: ApiKey) {
    await this.store.write(`api_keys/${key.id}.md`, serialize("api_keys", key));
  }

  /**
   * Re-reads the file right before writing and changes only `last_used_at`, so a revoke that landed after
   * the caller's lookup is kept (files have no single-field update; the read-write window is just this call).
   */
  async touchApiKey(id: string, at: string) {
    const key = await this.getApiKey(id);
    if (!key) return null;
    const next: ApiKey = { ...key, last_used_at: at };
    await this.saveApiKey(next);
    return next;
  }
}
