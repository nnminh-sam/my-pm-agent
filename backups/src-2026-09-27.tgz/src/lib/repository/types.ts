import type { ApiKey, Feature, Project, Task, User } from "../types";

export type TaskDraft = Omit<Task, "id" | "depends_on"> & {
  /** Existing task ids, or `{ index }` of another draft in the same batch. */
  depends_on: (string | { index: number })[];
};

/** The workspace records. Users and API keys are deliberately not included (they stay out of import/export). */
export interface Records {
  tasks: Task[];
  features: Feature[];
  projects: Project[];
  /** Records that couldn't be parsed; they're skipped rather than breaking everything. */
  problems: string[];
}

/**
 * Storage backend behind `src/lib/repo.ts`. Validation and domain rules live in repo.ts;
 * a backend only persists records and allocates ids.
 */
export interface Repository {
  readonly kind: "fs" | "postgres";
  /** Settings as stored (defaults not applied), or null when none have been saved. */
  readSettings(): Promise<Record<string, unknown> | null>;
  writeSettings(data: Record<string, unknown>): Promise<void>;
  loadAll(): Promise<Records>;
  getTask(id: string): Promise<Task | null>;
  getFeature(id: string): Promise<Feature | null>;
  getProject(id: string): Promise<Project | null>;
  /** Allocates the next ids and stores the whole batch, resolving `{ index }` dependencies. */
  insertTasks(drafts: TaskDraft[]): Promise<Task[]>;
  insertFeature(draft: Omit<Feature, "id">): Promise<Feature>;
  insertProject(draft: Omit<Project, "id">): Promise<Project>;
  saveTasks(tasks: Task[]): Promise<void>;
  saveFeature(feature: Feature): Promise<void>;
  saveProject(project: Project): Promise<void>;
  getUser(id: string): Promise<User | null>;
  /** Exact match; the caller passes an already-normalized email. */
  findUserByEmail(email: string): Promise<User | null>;
  countUsers(): Promise<number>;
  /** Allocates the next U- id and stores the user; null (nothing written) when the email is taken. */
  insertUser(draft: Omit<User, "id">): Promise<User | null>;
  /** Allocates the next K- id and stores the key (its hash only; raw keys are never persisted). */
  insertApiKey(draft: Omit<ApiKey, "id">): Promise<ApiKey>;
  /** Exact match on the lowercase hex SHA-256; revoked keys are returned too (the caller checks revoked_at). */
  findApiKeyByHash(hash: string): Promise<ApiKey | null>;
  /** Every key, revoked ones included, sorted by id number. */
  listApiKeys(): Promise<ApiKey[]>;
  getApiKey(id: string): Promise<ApiKey | null>;
  saveApiKey(key: ApiKey): Promise<void>;
  /**
   * Sets only `last_used_at` (a UTC ISO instant), leaving every other field, `revoked_at` included, as
   * currently stored, so a concurrent revoke is never undone. The updated key, or null for an unknown id.
   */
  touchApiKey(id: string, at: string): Promise<ApiKey | null>;
}

export const idNumber = (id: string) => Number(id.split("-")[1]) || 0;

export function resolveDeps(deps: TaskDraft["depends_on"], ids: string[]): string[] {
  return deps.map((dep) => (typeof dep === "string" ? dep : ids[dep.index]));
}
