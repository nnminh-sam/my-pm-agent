import { z } from "zod";
import type { Db, Row, Statement } from "../db";
import {
  ApiKeyMeta,
  FeatureMeta,
  ProjectMeta,
  TaskMeta,
  UserMeta,
  type ApiKey,
  type Feature,
  type Project,
  type Task,
  type User,
} from "../types";
import { resolveDeps, type Records, type Repository, type TaskDraft } from "./types";

type Table = "tasks" | "features" | "projects";
type Entity = Task | Feature | Project;

const META = { tasks: TaskMeta, features: FeatureMeta, projects: ProjectMeta };
const SEQUENCE = { tasks: "task_id_seq", features: "feature_id_seq", projects: "project_id_seq" };
/** Column names are the zod schema keys (types.ts is the single source) plus the markdown body. */
const COLUMNS = {
  tasks: [...Object.keys(TaskMeta.shape), "body"],
  features: [...Object.keys(FeatureMeta.shape), "body"],
  projects: [...Object.keys(ProjectMeta.shape), "body"],
};
const DATE_COLUMNS = new Set(["deadline", "not_before", "created", "completed"]);

const col = (name: string) => `"${name}"`;
// Dates come back as YYYY-MM-DD text rather than driver-parsed Date objects.
const selectList = (table: Table) =>
  COLUMNS[table].map((c) => (DATE_COLUMNS.has(c) ? `${col(c)}::text as ${col(c)}` : col(c))).join(", ");
const ORDER_BY_ID = "split_part(id, '-', 2)::int";

/** `users` (migrations/002_users.sql): no body column, and not part of loadAll / import. */
const USER_SELECT = Object.keys(UserMeta.shape)
  .map((c) => (DATE_COLUMNS.has(c) ? `${col(c)}::text as ${col(c)}` : col(c)))
  .join(", ");
const userFromRow = (row: Row): User => UserMeta.parse(row);

/** `api_keys` (migrations/003_api_keys.sql): frontmatter-like columns only, not part of loadAll / import. */
const API_KEY_COLUMNS = Object.keys(ApiKeyMeta.shape);
const TIMESTAMP_COLUMNS = new Set(["last_used_at", "revoked_at"]);
// timestamptz comes back as the same UTC ISO string it was written from (`Date#toISOString()`).
const API_KEY_SELECT = API_KEY_COLUMNS.map((c) =>
  DATE_COLUMNS.has(c)
    ? `${col(c)}::text as ${col(c)}`
    : TIMESTAMP_COLUMNS.has(c)
      ? `to_char(${col(c)} at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"') as ${col(c)}`
      : col(c),
).join(", ");
const apiKeyFromRow = (row: Row): ApiKey =>
  // NULL columns are absent optional fields, as for the workspace tables.
  ApiKeyMeta.parse(Object.fromEntries(Object.entries(row).filter(([, v]) => v !== null)));
const apiKeyParams = (key: Omit<ApiKey, "id">) => [
  key.label,
  key.hash,
  key.created,
  key.last_used_at ?? null,
  key.revoked_at ?? null,
  key.user_id ?? null,
];

function fromRow<T extends Entity>(table: Table, row: Row): T {
  const { body, ...meta } = row;
  // NULL columns are absent optional fields, exactly like a missing frontmatter key.
  const data = Object.fromEntries(Object.entries(meta).filter(([, v]) => v !== null));
  return { ...META[table].parse(data), body: (body as string | null) ?? "" } as T;
}

function insert(table: Table, entity: Entity): Statement {
  const cols = COLUMNS[table];
  const record = entity as Entity & Record<string, unknown>;
  return {
    text: `insert into ${table} (${cols.map(col).join(", ")}) values (${cols.map((_, i) => `$${i + 1}`).join(", ")})`,
    params: cols.map((c) => record[c] ?? null),
  };
}

function update(table: Table, entity: Entity): Statement {
  const cols = COLUMNS[table].filter((c) => c !== "id");
  const record = entity as Entity & Record<string, unknown>;
  return {
    text: `update ${table} set ${cols.map((c, i) => `${col(c)} = $${i + 2}`).join(", ")} where id = $1`,
    params: [entity.id, ...cols.map((c) => record[c] ?? null)],
  };
}

export interface ImportData extends Omit<Records, "problems"> {
  settings: Record<string, unknown> | null;
}

/** Relational rows in Postgres (`migrations/`), one sequence per id prefix. */
export class PgRepository implements Repository {
  readonly kind = "postgres";

  constructor(private readonly db: Db) {}

  async readSettings() {
    const rows = await this.db.query("select data from settings where id");
    return rows.length ? (rows[0].data as Record<string, unknown>) : null;
  }

  async writeSettings(data: Record<string, unknown>) {
    await this.db.query(
      "insert into settings (id, data) values (true, $1::json) on conflict (id) do update set data = excluded.data",
      [JSON.stringify(data)],
    );
  }

  private async loadTable<T extends Entity>(table: Table, problems: string[]) {
    const rows = await this.db.query(`select ${selectList(table)} from ${table} order by ${ORDER_BY_ID}`);
    const items: T[] = [];
    for (const row of rows) {
      try {
        items.push(fromRow<T>(table, row));
      } catch (err) {
        problems.push(`${table}/${row.id}: ${err instanceof z.ZodError ? z.prettifyError(err) : (err as Error).message}`);
      }
    }
    return items;
  }

  async loadAll(): Promise<Records> {
    const problems: string[] = [];
    const [tasks, features, projects] = await Promise.all([
      this.loadTable<Task>("tasks", problems),
      this.loadTable<Feature>("features", problems),
      this.loadTable<Project>("projects", problems),
    ]);
    return { tasks, features, projects, problems };
  }

  private async get<T extends Entity>(table: Table, id: string) {
    const rows = await this.db.query(`select ${selectList(table)} from ${table} where id = $1`, [id]);
    return rows.length ? fromRow<T>(table, rows[0]) : null;
  }

  getTask(id: string) {
    return this.get<Task>("tasks", id);
  }

  getFeature(id: string) {
    return this.get<Feature>("features", id);
  }

  getProject(id: string) {
    return this.get<Project>("projects", id);
  }

  private async nextIds(table: Table, count: number, prefix: string) {
    const rows = await this.db.query(
      `select nextval('${SEQUENCE[table]}')::int as n from generate_series(1, $1::int) order by 1`,
      [count],
    );
    return rows.map((r) => `${prefix}-${r.n}`);
  }

  async insertTasks(drafts: TaskDraft[]) {
    if (!drafts.length) return [];
    // Ids come first so forward refs resolve before anything is written; the inserts are one transaction.
    const ids = await this.nextIds("tasks", drafts.length, "T");
    const tasks: Task[] = drafts.map((draft, i) => ({ id: ids[i], ...draft, depends_on: resolveDeps(draft.depends_on, ids) }));
    await this.db.transaction(tasks.map((t) => insert("tasks", t)));
    return tasks;
  }

  async insertFeature(draft: Omit<Feature, "id">) {
    const [id] = await this.nextIds("features", 1, "F");
    const feature: Feature = { id, ...draft };
    await this.db.transaction([insert("features", feature)]);
    return feature;
  }

  async insertProject(draft: Omit<Project, "id">) {
    const [id] = await this.nextIds("projects", 1, "PRJ");
    const project: Project = { id, ...draft };
    await this.db.transaction([insert("projects", project)]);
    return project;
  }

  async saveTasks(tasks: Task[]) {
    if (tasks.length) await this.db.transaction(tasks.map((t) => update("tasks", t)));
  }

  async saveFeature(feature: Feature) {
    await this.db.transaction([update("features", feature)]);
  }

  async saveProject(project: Project) {
    await this.db.transaction([update("projects", project)]);
  }

  async getUser(id: string) {
    const rows = await this.db.query(`select ${USER_SELECT} from users where id = $1`, [id]);
    return rows.length ? userFromRow(rows[0]) : null;
  }

  async findUserByEmail(email: string) {
    const rows = await this.db.query(`select ${USER_SELECT} from users where email = $1`, [email]);
    return rows.length ? userFromRow(rows[0]) : null;
  }

  async countUsers() {
    const [row] = await this.db.query("select count(*)::int as n from users");
    return Number(row.n);
  }

  async insertUser(draft: Omit<User, "id">) {
    // The id comes from the column default; a taken email inserts nothing (and returns no row).
    const rows = await this.db.query(
      `insert into users (email, password_hash, created) values ($1, $2, $3) on conflict (email) do nothing returning ${USER_SELECT}`,
      [draft.email, draft.password_hash, draft.created],
    );
    return rows.length ? userFromRow(rows[0]) : null;
  }

  async insertApiKey(draft: Omit<ApiKey, "id">) {
    // The id comes from the column default.
    const [row] = await this.db.query(
      `insert into api_keys (label, hash, created, last_used_at, revoked_at, user_id) values ($1, $2, $3, $4::timestamptz, $5::timestamptz, $6) returning ${API_KEY_SELECT}`,
      apiKeyParams(draft),
    );
    return apiKeyFromRow(row);
  }

  async findApiKeyByHash(hash: string) {
    const rows = await this.db.query(`select ${API_KEY_SELECT} from api_keys where hash = $1`, [hash]);
    return rows.length ? apiKeyFromRow(rows[0]) : null;
  }

  async listApiKeys() {
    const rows = await this.db.query(`select ${API_KEY_SELECT} from api_keys order by ${ORDER_BY_ID}`);
    return rows.map(apiKeyFromRow);
  }

  async getApiKey(id: string) {
    const rows = await this.db.query(`select ${API_KEY_SELECT} from api_keys where id = $1`, [id]);
    return rows.length ? apiKeyFromRow(rows[0]) : null;
  }

  async saveApiKey(key: ApiKey) {
    await this.db.query(
      "update api_keys set label = $2, hash = $3, created = $4, last_used_at = $5::timestamptz, revoked_at = $6::timestamptz, user_id = $7 where id = $1",
      [key.id, ...apiKeyParams(key)],
    );
  }

  /** A single-column update: a revoke landing between a request's lookup and this touch is kept. */
  async touchApiKey(id: string, at: string) {
    const rows = await this.db.query(
      `update api_keys set last_used_at = $2::timestamptz where id = $1 returning ${API_KEY_SELECT}`,
      [id, at],
    );
    return rows.length ? apiKeyFromRow(rows[0]) : null;
  }

  /** Whether the workspace is empty; users and API keys don't count (they're never imported or replaced). */
  async isEmpty() {
    const [row] = await this.db.query(
      "select (select count(*) from projects) + (select count(*) from features) + (select count(*) from tasks) + (select count(*) from settings) as n",
    );
    return Number(row.n) === 0;
  }

  /** Writes everything in one transaction (parents first) and moves each id sequence past the imported max. */
  async importAll(data: ImportData, { replace = false } = {}) {
    const statements: Statement[] = [];
    // Users and API keys are left alone: they aren't part of the transferred data.
    if (replace) for (const table of ["tasks", "features", "projects", "settings"]) statements.push({ text: `delete from ${table}` });
    statements.push(...data.projects.map((p) => insert("projects", p)));
    statements.push(...data.features.map((f) => insert("features", f)));
    statements.push(...data.tasks.map((t) => insert("tasks", t)));
    if (data.settings) statements.push({ text: "insert into settings (id, data) values (true, $1::json)", params: [JSON.stringify(data.settings)] });
    for (const table of ["tasks", "features", "projects"] as const) {
      statements.push({
        text: `select setval('${SEQUENCE[table]}', coalesce((select max(${ORDER_BY_ID}) from ${table}), 0) + 1, false)`,
      });
    }
    await this.db.transaction(statements);
  }
}
